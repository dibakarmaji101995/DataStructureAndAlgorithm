package com.tyss.sorting;

import java.util.Arrays;

import lombok.extern.java.Log;

@Log
public class BubbleSort {

	/**
	 * 
	 * @param unsortedArray
	 */
	public void bubbleSort(Integer[] unsortedArray) {
		for (int i = 0; i < unsortedArray.length; i++) {
			for (int j = 0; j < unsortedArray.length - i - 1; j++) {
				if (unsortedArray[j] > unsortedArray[j + 1]) {
					swap(j, j + 1, unsortedArray);
				}
			}
		}
	}

	public void swap(Integer firstIndex, Integer secondIndex, Integer[] unsortedArray) {
		Integer tempValue = unsortedArray[firstIndex];
		unsortedArray[firstIndex] = unsortedArray[secondIndex];
		unsortedArray[secondIndex] = tempValue;
	}
	
	public static void main(String[] args) {
		// create Un-Sorted array
		Integer[] unsortedArray = new Integer[] {30,20,10,60,50,40};
		// create Object of BubbleSort class
		BubbleSort bs = new BubbleSort();
		// print unsorted array before sort
		log.info("Un-Sorted Array::"+Arrays.asList(unsortedArray));
		// sort the given unsorted array by using Bubble sort
		bs.bubbleSort(unsortedArray);
		
		//print sorted array after sort un-sorted array
		log.info("Sorted Array after Bubble Sort::"+Arrays.asList(unsortedArray));
		
	}
}
