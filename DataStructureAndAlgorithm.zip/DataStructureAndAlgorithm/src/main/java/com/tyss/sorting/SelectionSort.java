package com.tyss.sorting;

import java.util.Arrays;

import lombok.extern.java.Log;

@Log
public class SelectionSort {

	/**
	 * This method is used for sort given unsorted array by using selection sort
	 * algorithm
	 * 
	 * @param unsortedArray
	 */
	public void selectionSort(Integer[] unsortedArray) {
		for (int i = 0; i < unsortedArray.length; i++) {
			Integer minValueIndex = i;
			for (int j = i + 1; j < unsortedArray.length; j++) {
				if (unsortedArray[j] < unsortedArray[minValueIndex]) {
					minValueIndex = j;
				}
			}
			if (i != minValueIndex) {
				swap(i, minValueIndex, unsortedArray);
			}
		}
	}

	/**
	 * This method is used for swap two indexs value
	 * 
	 * @param firstIndex
	 * @param secondIndex
	 * @param unsortedArray
	 */
	public void swap(Integer firstIndex, Integer secondIndex, Integer[] unsortedArray) {
		Integer tempValue = unsortedArray[firstIndex];
		unsortedArray[firstIndex] = unsortedArray[secondIndex];
		unsortedArray[secondIndex] = tempValue;
	}

	public static void main(String[] args) {
		// create Un-Sorted array
		Integer[] unsortedArray = new Integer[] { 30, 20, 10, 60, 50, 40 };
		// create Object of BubbleSort class
		SelectionSort ss = new SelectionSort();
		// print unsorted array before sort
		log.info("Un-Sorted Array::" + Arrays.asList(unsortedArray));
		// sort the given unsorted array by using Bubble sort
		ss.selectionSort(unsortedArray);

		// print sorted array after sort un-sorted array
		log.info("Sorted Array after Selection Sort::" + Arrays.asList(unsortedArray));

	}
}
