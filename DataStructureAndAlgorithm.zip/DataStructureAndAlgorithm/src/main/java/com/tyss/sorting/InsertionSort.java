package com.tyss.sorting;

import java.util.Arrays;

import lombok.extern.java.Log;

@Log
public class InsertionSort {

	/**
	 * This method is used for sort given unsorted array by using Insertion Sort Algorithm
	 * @param unsortdArray
	 */
	public void insertionSort(Integer[] unsortdArray) {
		for (int i = 1; i < unsortdArray.length; i++) {
			// take first element index from unsorted array
			Integer firstElementIndex = i;
			for (int j = i - 1; j >= 0; j--) {
				if (unsortdArray[firstElementIndex] < unsortdArray[j]) {
					swap(firstElementIndex, j, unsortdArray);
					firstElementIndex = j;
				}
			}
		}
	}

	/**
	 * This method is used for swap two indexs value
	 * @param firstIndex
	 * @param secondIndex
	 * @param unsortedArray
	 */
	public void swap(Integer firstIndex, Integer secondIndex, Integer[] unsortedArray) {
		Integer tempValue = unsortedArray[firstIndex];
		unsortedArray[firstIndex] = unsortedArray[secondIndex];
		unsortedArray[secondIndex] = tempValue;
	}

	public static void main(String[] args) {
		// create Un-Sorted array
		Integer[] unsortedArray = new Integer[] { 30, 20, 10, 60, 40, 50, 40 };
		// create Object of InsertionSort class
		InsertionSort is = new InsertionSort();
		// print unsorted array before sort
		log.info("Un-Sorted Array::" + Arrays.asList(unsortedArray));
		// sort the given unsorted array by using Insertion sort
		is.insertionSort(unsortedArray);

		// print sorted array after sort un-sorted array
		log.info("Sorted Array after Insertion Sort::" + Arrays.asList(unsortedArray));

	}
}
