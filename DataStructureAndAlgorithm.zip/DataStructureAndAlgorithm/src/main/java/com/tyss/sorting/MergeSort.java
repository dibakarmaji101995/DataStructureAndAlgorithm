package com.tyss.sorting;

import java.util.Arrays;

import lombok.extern.java.Log;

@Log
public class MergeSort {

	public void mergeSort(int[] unsortedArray, int startIndex, int endIndex) {
		// base case/condition
		if (endIndex == startIndex) {
			return;
		} else { // recursive case/condition
			// get mid index of unsorted array
			Integer midIndex = (endIndex + startIndex) / 2;
			// recursive call left half array util too small chunk of left half array
			mergeSort(unsortedArray, startIndex, midIndex);
			// recursive call right half array util too small chunk of right half array
			mergeSort(unsortedArray, midIndex + 1, endIndex);
			// merge left and right sub-array as final o/p array will be sorted array
			merge(unsortedArray, startIndex, midIndex, endIndex);
		}
	}

	public void merge(int[] unsortedArray, int startIndex, int midIndex, int endIndex) {
		// create two temporary arrays
		int[] leftSubArray = new int[midIndex - startIndex + 2];
		int[] rightSubArray = new int[endIndex - midIndex + 1];
		// copy startIndex to midIndex into leftSubTree
		for (int i = 0; i <= midIndex - startIndex; i++) {
			leftSubArray[i] = unsortedArray[startIndex + i];
		}
		// copy midIndex to endIndex of unsortedArray into rightSubArray
		for (int i = 0; i < endIndex - midIndex; i++) {
			rightSubArray[i] = unsortedArray[midIndex + 1 + i];
		}
		leftSubArray[midIndex - startIndex + 1] = Integer.MAX_VALUE;
		rightSubArray[endIndex - midIndex] = Integer.MAX_VALUE;
		int i = 0;
		int j = 0;
		for (int k = startIndex; k <= endIndex; k++) {
			if (leftSubArray[i] < rightSubArray[j]) {
				unsortedArray[k] = leftSubArray[i];
				++i;
			} else {
				unsortedArray[k] = rightSubArray[j];
				++j;
			}
		}
	}

	public static void main(String[] args) {
		// create Un-Sorted array
		int[] unsortedArray = new int[] { 30, 20, 10, 60, 40, 50, 40 };
		// create Object of MergeSort class
		MergeSort ms = new MergeSort();
		// print unsorted array before sort
		log.info("Un-Sorted Array::");
		for (int i = 0; i < unsortedArray.length; i++) {
			System.out.print(unsortedArray[i] + " ");
		}
		// sort the given unsorted array by using Merge sort
		ms.mergeSort(unsortedArray, 0, unsortedArray.length - 1);

		// print sorted array after sort un-sorted array
		log.info("Sorted Array after Merge Sort::");
		for (int i = 0; i < unsortedArray.length; i++) {
			System.out.print(unsortedArray[i] + " ");
		}
	}
}
