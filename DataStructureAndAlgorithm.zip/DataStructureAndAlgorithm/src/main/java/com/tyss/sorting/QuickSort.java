package com.tyss.sorting;

import java.util.Arrays;

import lombok.extern.java.Log;

@Log
public class QuickSort {
    
	public void quickSort(Integer[] unsortedArray, Integer startIndex, Integer endIndex) {
		// base case/condition
		if(endIndex <= startIndex) {
			return;
		}else { // recursive case/condition
			Integer pivotalIndex = privotal(unsortedArray, startIndex, endIndex);
			// recursive call for left sub-array(before pivotal)
			quickSort(unsortedArray, startIndex, pivotalIndex-1);
			// recursive call for right sub-array(after pivotal)
			quickSort(unsortedArray, pivotalIndex +1, endIndex);
		}
	}
	
	public Integer privotal(Integer[] unsortedArray, Integer startIndex, Integer endIndex) {
		// take pivotalIndex as end index
		Integer pivotalIndex = endIndex;
		// pivotal current index after find its index element current position
		Integer currentPivotalIndex = 0;
		// set i= start-1
		Integer i = startIndex - 1;
		//logic to find pivotal  and sort left and right sub array of pivotal 
		for (int j = startIndex; j <=pivotalIndex ; j++) {
			if (unsortedArray[j] <= unsortedArray[pivotalIndex]) {
				// increase i
				++i;
				// swap i and j index elemets
				swap(unsortedArray, i, j);
				// set currentPivotalIndex as i value
				currentPivotalIndex = i;
			}
		}
		// return currentPivotalIndex
		return currentPivotalIndex;
	}
	
	public void swap(Integer[] unsortedArray, Integer firstIndex, Integer secondIndex) {
		// take one idex value in temp variable
		Integer tempValue = unsortedArray[firstIndex];
		// initialize secondIndex value to firstIndex
		unsortedArray[firstIndex] = unsortedArray[secondIndex];
		// initialize temp value to secondIndex
		unsortedArray[secondIndex] = tempValue;
	}
	
	public static void main(String[] args) {
		// create Un-Sorted array
		Integer[] unsortedArray = new Integer[] { 30, 20, 10, 60, 40, 50, 90, 5 };
		// create Object of QuickSort class
		QuickSort qc = new QuickSort();
		// print unsorted array before sort
		log.info("Un-Sorted Array::");
		System.out.println("Un-Sorted Array ::"+Arrays.asList(unsortedArray));
		// sort the given unsorted array by using Quick sort
		qc.quickSort(unsortedArray, 0, unsortedArray.length - 1);

		// print sorted array after sort un-sorted array
		log.info("Sorted Array after Quick Sort::");
		System.out.println("Quick Sort elements ::"+Arrays.asList(unsortedArray));
	}
	
}
