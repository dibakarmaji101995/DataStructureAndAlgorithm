package com.tyss.sorting;

import java.util.Arrays;

import lombok.extern.java.Log;

@Log
public class HeapSort {
	
	private Object[] binaryHeap;
	private Integer lastUsedIndex;
	
	/**
	 * 
	 * @param size
	 */
	public void createBinaryHeap(Integer size) {
		// create array with given size + 1
		binaryHeap = new Object[size + 1];
		// set lastUsedIndex to 0
		lastUsedIndex = 0;
	}

	/**
	 * 
	 * @param insertValue
	 */
	public void insert(Object insertValue) {
		if (binaryHeap == null) {
			log.info("Binary Heap is not exists");
		} else {
			// insert first vacant index of array
			binaryHeap[lastUsedIndex + 1] = insertValue;
			// increase lastUsedIndex
			++lastUsedIndex;
			// heapify Bottom to top
			heapifyBottomToTop(lastUsedIndex);
		}
	}

	/**
	 * This method is used for heapify index value from bottom to top
	 * 
	 * @param lastUsedIndex
	 */
	public void heapifyBottomToTop(Integer lastUsedIndex) {
		// base case/condition
		if (lastUsedIndex.equals(0)) {
			return;
			// recursive case/condition
		} else if ((lastUsedIndex / 2) != 0
				&& (Integer) binaryHeap[lastUsedIndex] < (Integer) binaryHeap[lastUsedIndex / 2]) {
			Integer temp = (Integer) binaryHeap[lastUsedIndex];
			binaryHeap[lastUsedIndex] = binaryHeap[lastUsedIndex / 2];
			binaryHeap[lastUsedIndex / 2] = temp;
			heapifyBottomToTop(lastUsedIndex / 2);
		}

	}

	/**
	 * This method is used for extract min/max number from Binary Heap
	 * 
	 * @return
	 */
	public Object extract() {
		Object extractValue = null;
		if (binaryHeap == null) {
			log.info("Binary Heap is does not exists");
		} else {
			// extract 1st index of BinaryHeap
			extractValue = binaryHeap[1];
			// update 1st index value with last index value
			binaryHeap[1] = binaryHeap[lastUsedIndex];
			// delete last index value
			binaryHeap[lastUsedIndex] = null;
			// decrease lastUsedIndex
			--lastUsedIndex;
			// heapify Binary Heap
			heapifyTopToBottom(1);
		}
		return extractValue;
	}

	/**
	 * This method is used for heapify index value from top to bottom
	 * 
	 * @param lastUsedIndex
	 */
	public void heapifyTopToBottom(Integer lastUsedIndex) {
		Integer left  = lastUsedIndex*2;
		Integer right = (lastUsedIndex*2)+1;
		Integer smallestChild = 0;
		
		if (this.lastUsedIndex < left) { //If there is no child of this node, then nothing to do. Just return.
			return; 
		}else if (this.lastUsedIndex == left) { //If there is only left child of this node, then do a comparison and return.
			if((Integer)binaryHeap[lastUsedIndex] > (Integer)binaryHeap[left] ) {
				Object tmp = binaryHeap[lastUsedIndex];
				binaryHeap[lastUsedIndex] = binaryHeap[left];
				binaryHeap[left] = tmp;
			}
			return;
		}else { //If both children are there
			if((Integer)binaryHeap[left] < (Integer)binaryHeap[right]) { //Find out the smallest child
				smallestChild = left;
			}else {
				smallestChild = right;
			}
			if((Integer)binaryHeap[lastUsedIndex] > (Integer)binaryHeap[smallestChild]) { //If Parent is greater than smallest child, then swap
				Object tmp = binaryHeap[lastUsedIndex];
				binaryHeap[lastUsedIndex] = binaryHeap[smallestChild];
				binaryHeap[smallestChild] = tmp;
			}
		}
		heapifyTopToBottom(smallestChild);
	}
	
	public void heapSort(Integer[] unsortedArray) {
		// create Binary Heap
		createBinaryHeap(unsortedArray.length);
		// insert unsorted elements into binaryHeap
		for (int i = 0; i < unsortedArray.length; i++) {
			insert(unsortedArray[i]);
		}
		// extract element from BinaryHeap until heap is empty and store into unsorted array
		for (int i = 0; i < unsortedArray.length; i++) {
			Object extractElement = extract();
			// store into unsorted array
			unsortedArray[i] = (Integer) extractElement;
		}
	}
	
	public static void main(String[] args) {
		// create Un-Sorted array
		Integer[] unsortedArray = new Integer[] { 30, 20, 10, 60, 40, 50, 90, 5 };
		// create Object of HeapSort class
		HeapSort qc = new HeapSort();
		// print unsorted array before sort
		log.info("Un-Sorted Array::");
		System.out.println("Un-Sorted Array ::"+Arrays.asList(unsortedArray));
		// sort the given unsorted array by using Heap sort
		qc.heapSort(unsortedArray);

		// print sorted array after sort un-sorted array
		log.info("Sorted Array after Heap Sort::");
		System.out.println("Heap Sort elements ::"+Arrays.asList(unsortedArray));
	}

}
