package com.tyss;

import java.util.Scanner;

import lombok.extern.java.Log;

@Log
public class FindingFibonacciSeries {
	public static void main(String[] args) {
		// create Scanner class object
		Scanner sc = new Scanner(System.in);
		// take the number from keyboard for how many numbers of fibonacci series we want print
		log.info("Enter Number of numbers from fibonacci series ::");
		Integer count = sc.nextInt();
		// print/display fibonacci series upto given number
		Integer firstNum = 0;
		Integer secondNum = 1;
		Integer nextNum = 0;
		log.info("Fibonacci Series of "+count+" numbers is ::");
		System.out.print(firstNum +", "+secondNum+", ");
		while(count > 2) {
			nextNum = firstNum + secondNum;
			firstNum = secondNum;
			secondNum = nextNum;
			if(count == 3) {
				System.out.print(nextNum);
			}else {
				System.out.print(nextNum+", ");
			}
			--count;
		}
		
	}
}
