package com.tyss.search;

import java.util.Scanner;

import lombok.extern.java.Log;

@Log
public class LinearSearch {
     public static void main(String[] args) {
		// create Scanner class object
    	 Scanner sc = new Scanner(System.in);
    	// take one array of numbers
    	Integer[] numArray = new Integer[] {89,90,45,10,99,34,23};
    	// take search element(number)
        log.info("Enter Search Element ::");	
    	Integer searchElement = sc.nextInt();
    	// Linear searching logic
    	for(int i = 0; i < numArray.length; ++i) {
    		if(numArray[i] == searchElement) {
    			log.info("Element "+searchElement+" found at index "+i);
    			break;
    		}
    		if(i == numArray.length-1) {
    			log.info("Element "+searchElement+" not found in this array");
    		}
    	}
	}
}
