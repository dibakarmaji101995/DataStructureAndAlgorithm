package com.tyss.search;

import java.util.Arrays;
import java.util.Scanner;

import lombok.extern.java.Log;

@Log
public class BinarySearch {
	public static void main(String[] args) {
		// create Scanner class object
		Scanner sc = new Scanner(System.in);
		// take array of numbers
		Integer[] numArray = new Integer[] { 50, 20, 30, 89, 78, 34, 67 };
		// take search elements from keyboard
		log.info("Enter Search Element ::");
		Integer searchElement = sc.nextInt();
		// short(ascending/descending order) given array
		Arrays.sort(numArray);
		log.info("Dispaly sorted array ::" + Arrays.asList(numArray).toString());
		// search element from array
		Integer searchIndexNumber = searchElementFromArray(numArray, searchElement);
        // print/display search element index number
		if (searchIndexNumber.equals(-1)) {
			log.info(searchElement+" not found in the given array");	
		}else {
			log.info(searchElement+" found in index "+searchIndexNumber);	
		}
	}

	/**
	 * This method is used for search element from given array by using binary
	 * search algorithm
	 * @param numArray
	 * @param start
	 * @param end
	 * @return search element index number
	 */
	public static Integer searchElementFromArray(Integer[] numArray, Integer searchElement) {
		// start of index
		Integer start = 0;
		// end of index
		Integer end = numArray.length-1;
		// get mid index of array
		Integer midIndex = findMidIndex(numArray, start, end);
		while (midIndex !=0) {
			if (searchElement < numArray[0] || searchElement > numArray[end]) {
				return -1;
			}else if(searchElement.equals(numArray[midIndex])) {
				return midIndex;
			}else if ( searchElement > numArray[midIndex]) {
			     midIndex = findMidIndex(numArray, midIndex, end);	
			}else {
				midIndex = findMidIndex(numArray, start, midIndex);
			}
		}
		return midIndex;
	}

	/**
	 * This method is used for find mid index of array
	 * @param numArray
	 * @param start
	 * @param end
	 * @return mid index
	 */
	public static Integer findMidIndex(Integer[] numArray, Integer start, Integer end) {
		Integer[] halfArray = null;
		if (end.equals(numArray.length - 1)) {
			halfArray = Arrays.copyOfRange(numArray, start, end + 1);
		} else {
			halfArray = Arrays.copyOfRange(numArray, start, end);
		}

		// get mid index of array
		Integer midIndex = halfArray.length / 2;
		// return mid index element
		return start + midIndex;
	}
}
