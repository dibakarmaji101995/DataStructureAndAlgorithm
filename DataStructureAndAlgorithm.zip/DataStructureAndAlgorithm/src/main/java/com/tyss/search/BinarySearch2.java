package com.tyss.search;

import java.util.Arrays;
import java.util.Scanner;

import lombok.extern.java.Log;

@Log
public class BinarySearch2 {
	
	public static void main(String[] args) {
		log.info(args[0]+"");
		// create Scanner class object
		Scanner sc = new Scanner(System.in);
		// take array of numbers
		Integer[] numArray = new Integer[] { 50, 20, 30, 89, 78, 34, 67 };
		// take search elements from keyboard
		log.info("Enter Search Element ::");
		Integer searchElement = sc.nextInt();
		// short(ascending/descending order) given array
		Arrays.sort(numArray);
		log.info("Dispaly sorted array ::" + Arrays.asList(numArray).toString());
		// search element from array
		Integer searchIndexNumber = searchElementFromArray(numArray, searchElement);
        // print/display search element index number
		if (searchIndexNumber.equals(-1)) {
			log.info(searchElement+" not found in the given array");	
		}else {
			log.info(searchElement+" found in index "+searchIndexNumber);	
		}
	}

	/**
	 * This method is used for search element from given array by using binary
	 * search algorithm
	 * @param numArray
	 * @param start
	 * @param end
	 * @return search element index number
	 */
	public static Integer searchElementFromArray(Integer[] numArray, Integer searchElement) {
		// start of index
		Integer start = 0;
		// end of index
		Integer end = numArray.length - 1;
		
		while (start <= end) {
			// get mid index of array
			Integer midIndex = start + (end - start) / 2;
			// condition to search element else change start or end index	
		    if(searchElement.equals(numArray[midIndex])) {
				return midIndex;
			}else if ( searchElement > numArray[midIndex]) {
			     start = midIndex + 1;	
			}else if(searchElement < numArray[midIndex]){
				end = midIndex - 1;
			}
		}
		// if the given element is not found then we return -1 and 
		// here control will be come when given element is not found in this given array
		return -1;
	}
}
