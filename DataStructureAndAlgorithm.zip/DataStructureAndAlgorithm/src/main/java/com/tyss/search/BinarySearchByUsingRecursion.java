package com.tyss.search;

import java.util.Arrays;
import java.util.Scanner;

import lombok.extern.java.Log;

@Log
public class BinarySearchByUsingRecursion {

	public static void main(String[] args) {
		// create Scanner class object
		Scanner sc = new Scanner(System.in);
		// take search element from keyboard
		log.info("Enter Search Number ::");
		Integer searchElement = sc.nextInt();
		// create Integer array with 11 elements
		Integer[] numArray = new Integer[] { 45, 25, 32, 48, 78, 87, 12, 10, 50, 80};
		// sort the given array into ascending order
		Arrays.sort(numArray);
		log.info("Display sorted Array ::"+Arrays.asList(numArray).toString());
		// start index of an array
		Integer start = 0;
		// end index of an array
		Integer end = numArray.length - 1;
		// check search element is there in an array or not
		Integer searchElementIndex = searchingElementFromArray(searchElement, numArray, start, end);
		// print/display search element index
		if (searchElementIndex.equals(-1)) {
			log.info(searchElement + " is not found in the given array");
		} else {
			log.info(searchElement + " is found in index " + searchElementIndex);
		}

	}

	/**
	 * This method is used for search element from array by using binary search algorithm
	 * @param searchElement
	 * @param numArray
	 * @param start
	 * @param end
	 * @return search element index number
	 */
	public static Integer searchingElementFromArray(Integer searchElement, Integer[] numArray, Integer start,
			Integer end) {
		// base case/condition
		if (start.equals(end)) {
		//	if (numArray[start].equals(searchElement)) {
		//		return start;
		//	} else {
				return -1;
		//	}
		}
		Integer midIndex = findMidIndex(numArray, start, end);
		// Recursive case/condition
		if (searchElement.equals(numArray[midIndex])) {
			return midIndex;
		} else if (searchElement > numArray[midIndex]) {
			return searchingElementFromArray(searchElement, numArray, midIndex, end);
		} else {
			return searchingElementFromArray(searchElement, numArray, start, midIndex);
		}
	}
    
	/**
	 * This method is used for find mid index of array
	 * @param numArray
	 * @param start
	 * @param end
	 * @return mid index
	 */
	public static Integer findMidIndex(Integer[] numArray, Integer start, Integer end) {
		Integer[] halfArray = null;
		if(end.equals(numArray.length-1)) {
			halfArray = Arrays.copyOfRange(numArray, start, end+1);
		}else {
			halfArray = Arrays.copyOfRange(numArray, start, end);
		}
		
		// get mid index of array
		Integer midIndex = halfArray.length / 2;
		// return mid index element
		return start + midIndex;
	}
}
