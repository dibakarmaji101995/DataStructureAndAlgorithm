package com.tyss.binaryheap.test;

import com.tyss.binaryheap.BinaryHeap;

import lombok.extern.java.Log;

@Log
public class BinaryHeapTest {

	public static void main(String[] args) {
		// create BinaryHeap class object
		BinaryHeap binaryHeap = new BinaryHeap();

		// create empty BinaryHeap
		binaryHeap.createBinaryHeap(20);

		// insert value in BinaryHeap
		log.info("Insert value in Binary Heap");
		binaryHeap.insert(10);
		binaryHeap.insert(20);
		binaryHeap.insert(30);
		binaryHeap.insert(40);
		binaryHeap.insert(50);
		binaryHeap.insert(60);
		binaryHeap.insert(70);
		binaryHeap.insert(80);
		binaryHeap.insert(90);

		// traversal BinaryHeap
		log.info("Level-Order Traversal of Bianry Heap");
		binaryHeap.levelOrderTraversal();
		System.out.println();

		// insert small value in Binary Heap
		log.info("Insert small value in Binary Heap");
		binaryHeap.insert(5);

		// level order traversal after insert small value
		log.info("Level Order traversal after insert small value");
		binaryHeap.levelOrderTraversal();

		// extract min/max in Binary Heap
		log.info("Extract min value In Binary Heap");
		Object extractValue = binaryHeap.extract();
		log.info("Extract min value::" + extractValue);

		// level order traversal after extract min value
		log.info("Level Order traversal after extract min value");
		binaryHeap.levelOrderTraversal();
		
		// get size of Binary Heap
		log.info("Get size of Binary Heap");
		Integer size = binaryHeap.size();
		log.info("Size of Binary Heap::"+size);
		
		// get min/max number
		log.info("Get min/max number from Bianry Heap");
		Integer minValue = (Integer)binaryHeap.peek();
		log.info("Min value in Binary Heap is "+minValue);

	}
}
