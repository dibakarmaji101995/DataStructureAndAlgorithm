package com.tyss.binaryheap;

import lombok.extern.java.Log;

@Log
public class BinaryHeap {
	private Object[] binaryHeap;
	private Integer lastUsedIndex;

	/**
	 * 
	 * @param size
	 */
	public void createBinaryHeap(Integer size) {
		// create array with given size + 1
		binaryHeap = new Object[size + 1];
		// set lastUsedIndex to 0
		lastUsedIndex = 0;
	}

	/**
	 * 
	 * @param insertValue
	 */
	public void insert(Object insertValue) {
		if (binaryHeap == null) {
			log.info("Binary Heap is not exists");
		} else {
			// insert first vacant index of array
			binaryHeap[lastUsedIndex + 1] = insertValue;
			// increase lastUsedIndex
			++lastUsedIndex;
			// heapify Bottom to top
			heapifyBottomToTop(lastUsedIndex);
		}
	}

	/**
	 * This method is used for heapify index value from bottom to top
	 * 
	 * @param lastUsedIndex
	 */
	public void heapifyBottomToTop(Integer lastUsedIndex) {
		// base case/condition
		if (lastUsedIndex.equals(0)) {
			return;
			// recursive case/condition
		} else if ((lastUsedIndex / 2) != 0
				&& (Integer) binaryHeap[lastUsedIndex] < (Integer) binaryHeap[lastUsedIndex / 2]) {
			Integer temp = (Integer) binaryHeap[lastUsedIndex];
			binaryHeap[lastUsedIndex] = binaryHeap[lastUsedIndex / 2];
			binaryHeap[lastUsedIndex / 2] = temp;
			heapifyBottomToTop(lastUsedIndex / 2);
		}

	}

	/**
	 * This method is used for extract min/max number from Binary Heap
	 * 
	 * @return
	 */
	public Object extract() {
		Object extractValue = null;
		if (binaryHeap == null) {
			log.info("Binary Heap is does not exists");
		} else {
			// extract 1st index of BinaryHeap
			extractValue = binaryHeap[1];
			// update 1st index value with last index value
			binaryHeap[1] = binaryHeap[lastUsedIndex];
			// delete last index value
			binaryHeap[lastUsedIndex] = null;
			// decrease lastUsedIndex
			--lastUsedIndex;
			// heapify Binary Heap
			heapifyTopToBottom(1);
		}
		return extractValue;
	}

	/**
	 * This method is used for heapify index value from top to bottom
	 * 
	 * @param lastUsedIndex
	 */
	public void heapifyTopToBottom(Integer lastUsedIndex) {
		// base case/condition
		if (lastUsedIndex > this.lastUsedIndex) {
			return;
		} else if ((Integer) binaryHeap[lastUsedIndex] > (Integer) binaryHeap[2 * lastUsedIndex]) {
			Object temp = binaryHeap[lastUsedIndex];
			binaryHeap[lastUsedIndex] = binaryHeap[2 * lastUsedIndex];
			binaryHeap[2 * lastUsedIndex] = temp;
			heapifyTopToBottom(2 * lastUsedIndex);
		}
	}

	/**
	 * This method is used to get size of Binary Heap
	 * 
	 * @return
	 */
	public Integer size() {
		if (binaryHeap == null) {
			log.info("Binary Heap does not exists");
			return 0;
		} else {
			return lastUsedIndex;
		}
	}

	/**
	 * This method is used for get min/max number from Binary Heap
	 * 
	 * @return
	 */
	public Object peek() {
		if (binaryHeap == null) {
			log.info("Binary Heap does not exists");
			return null;
		} else {
			return binaryHeap[1];
		}
	}

	public void levelOrderTraversal() {
		for (int i = 0; i < binaryHeap.length; i++) {
			System.out.print(binaryHeap[i] + " ");
		}
	}
}
