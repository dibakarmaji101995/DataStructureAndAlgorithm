package com.tyss.queue;


import lombok.Data;
import lombok.extern.java.Log;

/**
 * 
 * @author diba
 *
 */
@Log
@Data
public class ArrayImplementationOfLinearQueue {

	/**
	 * This field is used for store array object
	 */
	private Object[] linearQueue;

	/**
	 * This field is used for store start of Linear Queue location
	 */
	private Integer startOfQueue;

	/**
	 * This field is used for store top of Linear Queue location
	 */
	private Integer topOfQueue;

	/**
	 * This method is used for create Linear Queue
	 * 
	 * @param size
	 */
	public void createLinearQueue(Integer size) {
		// instantiation of array with given size
		linearQueue = new Object[size];
		// initialize start and top
		startOfQueue = -1;
		topOfQueue = -1;
	}

	/**
	 * This method is used for Enqueue in LinearQueue
	 * 
	 * @param value
	 */
	public void enqueue(Object value) {
		if (linearQueue == null) {
			log.info("Create array before enqueue value in Linear Queue");
		} else {
			linearQueue[topOfQueue + 1] = value;
			topOfQueue++;
			startOfQueue = 0;
		}

	}

	/**
	 * This method is used for dequeue in Linear Queue
	 * 
	 * @return
	 */
	public Object dequeue() {
		Object tempValue = null;
		if (topOfQueue.equals(-1)) {
			return "Linear Queue is Empty";
		} else {
			tempValue = linearQueue[startOfQueue];
			linearQueue[startOfQueue] = null;
			startOfQueue++;
		}
		return tempValue;
	}

	/**
	 * This method is used for peek first element of queue
	 * 
	 * @return
	 */
	public Object peek() {
		if (topOfQueue.equals(-1)) {
			return "Linear Queue is Empty";
		} else {
			return linearQueue[startOfQueue];
		}
	}

	/**
	 * This method is used for check linear queue is empty or not
	 * 
	 * @return
	 */
	public Boolean isEmty() {
		if (topOfQueue.equals(-1) && startOfQueue.equals(-1)) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * This method is used for check Linear Queue is full or not
	 * 
	 * @return
	 */
	public Boolean isFull() {
		if (topOfQueue >= linearQueue.length - 1) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * This method is used for delete entire Linear Queue
	 */
	public void deleteLinearQueue() {
		// nullify array reference variable
		linearQueue = null;
		log.info("Delete is Done!!!!");
	}
	
	public void traversalOfLinearQueue() {
		if (linearQueue == null) {
			log.info("Linear Queue is Empty");
		}else {
			for (int i = 0; i < linearQueue.length; i++) {
				log.info("1st element value "+linearQueue[i]);
			}
		}
	}

}
