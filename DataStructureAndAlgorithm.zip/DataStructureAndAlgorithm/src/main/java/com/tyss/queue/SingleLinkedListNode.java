package com.tyss.queue;

import lombok.Data;

@Data
public class SingleLinkedListNode {
      private Object value;
      private SingleLinkedListNode next;
}
