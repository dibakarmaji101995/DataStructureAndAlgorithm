package com.tyss.queue;

import lombok.Data;
import lombok.extern.java.Log;

/**
 * 
 * @author diba
 *
 */
@Log
@Data
public class ArrayImplementationOfCircularQueue {

	/**
	 * This field is used for store array object
	 */
	private Object[] circularQueue;

	/**
	 * This field is used for store start of Linear Queue location
	 */
	private Integer startOfQueue;

	/**
	 * This field is used for store top of Linear Queue location
	 */
	private Integer topOfQueue;

	/**
	 * This method is used for create Linear Queue
	 * 
	 * @param size
	 */
	public void createLinearQueue(Integer size) {
		// instantiation of array with given size
		circularQueue = new Object[size];
		// initialize start and top
		startOfQueue = -1;
		topOfQueue = -1;
	}

	/**
	 * This method is used for Enqueue in LinearQueue
	 * 
	 * @param value
	 */
	public void enqueue(Object value) {
		if (!isFull()) {
			if (startOfQueue.equals(0) && topOfQueue <= circularQueue.length - 1) {
				circularQueue[topOfQueue + 1] = value;
				topOfQueue++;
			} else if (startOfQueue > 0 && topOfQueue == circularQueue.length - 1) {
				topOfQueue = 0;
				circularQueue[topOfQueue] = value;
			} else if (topOfQueue<startOfQueue) {
				circularQueue[topOfQueue + 1] = value;
				topOfQueue++;
			}else{
				circularQueue[topOfQueue + 1] = value;
				topOfQueue++;
				startOfQueue = 0;
			}
		}else {
			log.info("Array Is Full!!!");
		}

	}

	/**
	 * This method is used for dequeue in Linear Queue
	 * 
	 * @return
	 */
	public Object dequeue() {
		Object tempValue = null;
		if (topOfQueue.equals(-1)) {
			return "Linear Queue is Empty";
		} else if (topOfQueue.equals(0) && startOfQueue.equals(0)) {
			tempValue = circularQueue[startOfQueue];
			circularQueue[startOfQueue] = null;
			topOfQueue--;
			startOfQueue--;
		} else if (startOfQueue.equals(circularQueue.length - 1) && topOfQueue >= 0) {
			tempValue = circularQueue[startOfQueue];
			circularQueue[startOfQueue] = null;
			startOfQueue = 0;
		} else {
			tempValue = circularQueue[startOfQueue];
			circularQueue[startOfQueue] = null;
			startOfQueue++;
		}
		return tempValue;
	}

	/**
	 * This method is used for peek first element of queue
	 * 
	 * @return
	 */
	public Object peek() {
		if (topOfQueue.equals(-1)) {
			return "Linear Queue is Empty";
		} else {
			return circularQueue[startOfQueue];
		}
	}

	/**
	 * This method is used for check linear queue is empty or not
	 * 
	 * @return
	 */
	public Boolean isEmpty() {
		if (topOfQueue.equals(-1) && startOfQueue.equals(-1)) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * This method is used for check Linear Queue is full or not
	 * 
	 * @return
	 */
	public Boolean isFull() {
		if (startOfQueue.equals(0) && topOfQueue >= circularQueue.length - 1) {
			return true;
		} else if ((topOfQueue + 1) == startOfQueue) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * This method is used for delete entire Linear Queue
	 */
	public void deleteLinearQueue() {
		// nullify array reference variable
		circularQueue = null;
		log.info("Delete is Done!!!!");
	}

	public void traversalOfLinearQueue() {
		if (circularQueue == null) {
			log.info("Linear Queue is Empty");
		} else {
			for (int i = 0; i < circularQueue.length; i++) {
				log.info((i + 1) + " element value " + circularQueue[i]);
			}
		}
	}

}
