package com.tyss.queue.test;

import com.tyss.queue.ArrayImplementationOfLinearQueue;

import lombok.extern.java.Log;

@Log
public class ArrayImplementationOfLinearQueueTest {
     
	public static void main(String[] args) {
		// create ArrayImplementationOfLinearQueue class object
		ArrayImplementationOfLinearQueue linearQueue = new ArrayImplementationOfLinearQueue();
		
		// create Linear queue
		linearQueue.createLinearQueue(10);
		
		// enqueue in Linear Queue
		linearQueue.enqueue(10);
		linearQueue.enqueue(20);
		linearQueue.enqueue(30);
		linearQueue.enqueue(40);
		
		linearQueue.traversalOfLinearQueue();
		
		// isEmpty check
		log.info("isEmpty ::"+linearQueue.isEmty());
		
		// dequeue in Linear Queue
		Object num1 = linearQueue.dequeue();
		log.info("Deque element ::"+num1);
		Object num2 = linearQueue.dequeue();
		log.info("Deque element ::"+num2);
		
		linearQueue.traversalOfLinearQueue();
		
		// peek first element of Linear Queue
		Object peekElement = linearQueue.peek();
		log.info("Peek element ::"+peekElement);
		
		// isFull check in Linear Queue
		Boolean isFull = linearQueue.isFull();
		log.info("isFull ::"+isFull);
		
		// delete entire Linear Queue
		linearQueue.deleteLinearQueue();
		log.info("After delete Linear Queue ::"+linearQueue.getLinearQueue());
		
	}
}
