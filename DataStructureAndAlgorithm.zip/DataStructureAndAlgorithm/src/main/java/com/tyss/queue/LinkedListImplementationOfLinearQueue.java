package com.tyss.queue;

import lombok.extern.java.Log;

@Log
public class LinkedListImplementationOfLinearQueue {
	 private static LinkedListImplementationOfLinearQueue linearQueue;	
     private SingleLinkedListNode head;
     private SingleLinkedListNode tail;
     private Integer size;
     
     /**
      * This method is used to create Linear Queue
      * @return
      */
     public static LinkedListImplementationOfLinearQueue createLinearQueue() {
    	 if(linearQueue == null) {
    	    linearQueue = new LinkedListImplementationOfLinearQueue();
    	    linearQueue.size = 0;
    	    return linearQueue;
    	 }else {
    		linearQueue.size = 0;
			return linearQueue;
		}
     }
     
     /**
      * This method is used for enqueue in Linear Queue
      * @param value
      */
     public void enqueue(Object value) {
    	 //create empty node object
    	 SingleLinkedListNode node = new SingleLinkedListNode();
    	 // initialize node object fields
    	 node.setValue(value);
    	 node.setNext(null);
    	 if(head == null) {
    		 head = node;
        	 tail = node;
        	 size++;
    	 }else {
    		 tail.setNext(node);
    		 tail = node;
    		 size++;
    	 }
     }
     
     /**
      * This method is used for dequeue in Linear Queue
      * @return
      */
     public Object dequeue() {
    	 if(head == null) {
    		 return "Linear Queue is Empty";
    	 }else {
    		 Object tempValue = head.getValue();
    		 head = head.getNext();
    		 size--;
    		 return tempValue;
    		 
    	 }
     }
     
     /**
      * This method is used for peek first value from Linear Queue
      * @return
      */
     public Object peek() {
    	 if(head == null) {
    		 return "Linear Queue isEmpty";
    	 }else {
			return head.getValue();
		}
     }
     
     /**
      * This method is used for check Linear Queue is empty or not
      * @return
      */
     public Boolean isEmpty() {
    	 if(head == null) {
    		 return true;
    	 }else {
    		 return false;
    	 }
     }
     
     /**
      * This method is used for delete linear queue
      */
     public void deleteEntireLinearQueue() {
    	 // nullify head and tail
    	 head = null;
    	 tail = null;
    	 log.info("Delete Linear Queue is Done!!!");
     }
     
     public void traversalOfLinearQueue() {
 		if (linearQueue == null) {
 			log.info("Linear Queue is Empty");
 		} else {
 			SingleLinkedListNode tempNode = head;
 			for (int i = 0; i < size; i++) {
 				log.info("Node-"+(i + 1)+ " value " + tempNode.getValue());
 				tempNode = tempNode.getNext();
 			}
 		}
 	}
}
