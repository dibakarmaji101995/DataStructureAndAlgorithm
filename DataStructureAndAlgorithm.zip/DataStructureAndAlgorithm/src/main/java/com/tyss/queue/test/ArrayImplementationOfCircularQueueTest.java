package com.tyss.queue.test;

import com.tyss.queue.ArrayImplementationOfCircularQueue;
import com.tyss.queue.ArrayImplementationOfLinearQueue;

import lombok.extern.java.Log;

@Log
public class ArrayImplementationOfCircularQueueTest {
     
	public static void main(String[] args) {
		// create ArrayImplementationOfLinearQueue class object
		ArrayImplementationOfCircularQueue circularQueue = new ArrayImplementationOfCircularQueue();
		
		// create Linear queue
		circularQueue.createLinearQueue(4);
		
		// enqueue in Linear Queue
		circularQueue.enqueue(10);
		circularQueue.enqueue(20);
		circularQueue.enqueue(30);
		circularQueue.enqueue(40);
		
		circularQueue.traversalOfLinearQueue();
		
		// isEmpty check
		log.info("isEmpty ::"+circularQueue.isEmpty());
		
		// dequeue in Linear Queue
		Object num1 = circularQueue.dequeue();
		log.info("Deque element ::"+num1);
		Object num2 = circularQueue.dequeue();
		log.info("Deque element ::"+num2);
		
		circularQueue.traversalOfLinearQueue();
		
		// enqueue in Linear Queue
		circularQueue.enqueue(50);
		circularQueue.enqueue(60);
		circularQueue.enqueue(70);
		circularQueue.traversalOfLinearQueue();
		
		// peek first element of Linear Queue
		Object peekElement = circularQueue.peek();
		log.info("Peek element ::"+peekElement);
		
		// isFull check in Linear Queue
		Boolean isFull = circularQueue.isFull();
		log.info("isFull ::"+isFull);
		
		// delete entire Linear Queue
		circularQueue.deleteLinearQueue();
		log.info("After delete Linear Queue ::"+circularQueue.getCircularQueue()); 
		
	}
}
