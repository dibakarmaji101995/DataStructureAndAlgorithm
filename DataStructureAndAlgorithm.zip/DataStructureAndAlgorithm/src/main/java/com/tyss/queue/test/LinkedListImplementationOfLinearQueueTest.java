package com.tyss.queue.test;

import com.tyss.queue.LinkedListImplementationOfLinearQueue;

import lombok.extern.java.Log;

@Log
public class LinkedListImplementationOfLinearQueueTest {

	public static void main(String[] args) {

		// create Linear queue
		LinkedListImplementationOfLinearQueue linearQueue = LinkedListImplementationOfLinearQueue.createLinearQueue();

		// enqueue in Linear Queue
		linearQueue.enqueue(10);
		linearQueue.enqueue(20);
		linearQueue.enqueue(30);
		linearQueue.enqueue(40);

		linearQueue.traversalOfLinearQueue();

		// isEmpty check
		log.info("isEmpty ::" + linearQueue.isEmpty());

		// dequeue in Linear Queue
		Object num1 = linearQueue.dequeue();
		log.info("Deque element ::" + num1);
		Object num2 = linearQueue.dequeue();
		log.info("Deque element ::" + num2);

		linearQueue.traversalOfLinearQueue();

		// peek first element of Linear Queue
		Object peekElement = linearQueue.peek();
		log.info("Peek element ::" + peekElement);

		// delete entire Linear Queue
		linearQueue.deleteEntireLinearQueue();

	}
}
