package com.tyss;

import java.util.Scanner;

import lombok.extern.java.Log;

@Log
public class CheckTheGivenNumberIsPalindromeNumberOrNot {
	public static void main(String[] args) {
		// create Scanner class object
		Scanner sc = new Scanner(System.in);
		// take the number from keyboard for check it is palindrome number or not
		log.info("Enter any Number to check it is palindrome or not ::");
		Integer number = sc.nextInt();
		Integer temp = number;
		Integer reverseNum = 0;
		while (number != 0) {
			Integer lastDigit = number % 10;
			reverseNum = reverseNum * 10 + lastDigit;
			number = number / 10;
		}
		if (reverseNum.equals(temp)) {
			log.info(temp + " is a Palindrome Number");
		} else {
			log.info(temp + " is not a palindrome number ");
		}

	}
}
