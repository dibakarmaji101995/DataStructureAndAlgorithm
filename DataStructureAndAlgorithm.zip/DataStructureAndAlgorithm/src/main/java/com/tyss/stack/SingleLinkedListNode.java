package com.tyss.stack;

import lombok.Data;

@Data
public class SingleLinkedListNode {
     private Object value;
     private SingleLinkedListNode next;
}
