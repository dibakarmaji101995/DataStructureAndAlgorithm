package com.tyss.stack.test;

import java.util.Arrays;

import com.tyss.stack.ArrayImplementationOfStack;

import lombok.extern.java.Log;

@Log
public class ArrayImplementationOfStackTest {

	public static void main(String[] args) {
		// create ArrayImplementationOfStack class object
		ArrayImplementationOfStack stack = new ArrayImplementationOfStack();

		// create stack
		stack.createStack(10);

		// isEmpty check
		log.info("isEmpty Check ::" + stack.isEmpty());

		// push new element in stack
		stack.push(10);
		stack.push(15);
		stack.push(20);
		stack.push(30);
		log.info("Stack elements after push ::" + Arrays.asList(stack.getArr()));

		// pop in stack
		Object popElement = stack.pop();
		log.info("Pop Element is " + popElement);
		log.info("Stack elements after pop ::" + Arrays.asList(stack.getArr()));

		// peek in stack
		Object peekElement = stack.peek();
		log.info("Peek Element is " + peekElement);
		log.info("Stack elements after Peek ::" + Arrays.asList(stack.getArr()));

		// isEmpty check
		log.info("isEmpty Check ::" + stack.isEmpty());

		// isFull check
		log.info("isNull Check ::" + stack.isFull());

		// delete stack
		stack.deleteStack();
		log.info("Stack elements after delete stack ::" + stack.getArr());
	}

}
