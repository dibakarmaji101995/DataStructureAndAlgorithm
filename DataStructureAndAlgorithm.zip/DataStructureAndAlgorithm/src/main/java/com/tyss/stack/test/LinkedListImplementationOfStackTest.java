package com.tyss.stack.test;

import com.tyss.stack.LinkedListImplementationOfStack;

import lombok.extern.java.Log;

@Log
public class LinkedListImplementationOfStackTest {

	public static void main(String[] args) {
		// create ArrayImplementationOfStack class object
		LinkedListImplementationOfStack stack = new LinkedListImplementationOfStack();

		// create stack
		stack.createStack();

		// isEmpty check
		log.info("isEmpty Check ::" + stack.isEmpty());

		// push new element in stack
		stack.push(10);
		stack.push(15);
		stack.push(20);
		stack.push(30);
		log.info("Stack elements after push ::");
		stack.traversalOfLinkedList();

		// pop in stack
		Object popElement = stack.pop();
		log.info("Pop Element is " + popElement);
		log.info("Stack elements after pop ::");
		stack.traversalOfLinkedList();

		// peek in stack
		Object peekElement = stack.peek();
		log.info("Peek Element is " + peekElement);
		log.info("Stack elements after Peek ::");
		stack.traversalOfLinkedList();

		// isEmpty check
		log.info("isEmpty Check ::" + stack.isEmpty());

		// delete stack
		stack.deleteStack();
		log.info("Stack elements after delete stack ::");
		stack.traversalOfLinkedList();
	}

}
