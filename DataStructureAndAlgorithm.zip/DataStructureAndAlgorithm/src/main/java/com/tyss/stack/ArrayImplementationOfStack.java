package com.tyss.stack;

import lombok.Data;
import lombok.extern.java.Log;

@Log
@Data
public class ArrayImplementationOfStack {
	
	/**
	 * This field is used for store location of top of stack 
	 */
	private Integer topOfStack;
	
	/**
	 * This field is used for store created array reference
	 */
	private Object[] arr;
	
	/**
	 * This method is used for create empty array with given size
	 * @param size
	 */
	public void createStack(Integer size) {
		// create empty array with given size
		arr = new Integer[size];
		// initialize topOfStack
		topOfStack = -1;
		// print success message
		log.info("Creation of Stack is Done!!!!!!!");
	}
	
	/**
	 * This method is used for insert new element in top of stack
	 * @param value
	 */
	public void push(Object value) {
		if(arr == null) {
			// print error message
			log.info("Push operation can not perform because of array does not exists");
		}else {
			//insert value at top of stack
			arr[topOfStack+1] = value;	
			// increase topOfStatck
			++topOfStack;
		}
		
	}
	
	/**
	 * This method is used for remove and return element of top of stack
	 * @return
	 */
	public Object pop() {
		if(arr == null) {
			// print error message
			log.info("Push operation can not perform because of array does not exists");
			return 0;
		}else {
			// take element from top of stack
			Object topElement = arr[topOfStack];
			// remove element of top of stack
			arr[topOfStack] = null;
			// change location of top of stack
			--topOfStack;
			// return element of  top of stack
			return topElement;
		}
	}
	
	/**
	 * This method is used for peek element of top of stack
	 * @return
	 */
	public Object peek() {
		if(arr == null) {
			// print error message
			log.info("Push operation can not perform because of array does not exists");
			return 0;
		}else {
			// return element of  top of stack
			return arr[topOfStack];
		}
	}
	
	/**
	 * This method is used for check array is empty or not
	 * @return
	 */
	public Boolean isEmpty() {
		if(topOfStack.equals(-1)) {
			// return true
			return true;
		}else {
			// return false
			return false;
		}
	}
	
	/**
	 * This method is used for check array is full or not
	 * @return
	 */
	public Boolean isFull() {
		if(topOfStack >= arr.length-1) {
			// return true
			return true;
		}else {
			// return false
			return false;
		}
	}
	
	/**
	 * This method is used for delete stack
	 */
	public void deleteStack() {
		// nullify array
		arr = null;
		// print success message
		log.info("Stack delete is Done!!!!!!!");
	}

}
