package com.tyss.trie;

import java.util.HashMap;
import java.util.Map;

import lombok.Data;
import lombok.extern.java.Log;

@Data
@Log
public class Trie {

	private TrieNode root;

	/**
	 * create TrieNode class as private
	 * 
	 * @author princ
	 *
	 */
	private class TrieNode {
		private Map<Character, TrieNode> children;
		private Boolean endOfSring;

		public TrieNode() {
			children = new HashMap();
			endOfSring = false;
		}

		public Map<Character, TrieNode> getChildren() {
			return children;
		}

		public Boolean getEndOfSring() {
			return endOfSring;
		}

		
	}

	public Trie() {
		root = new TrieNode();
	}

	/**
	 * This method is used for insert word in Trie
	 * @param word
	 */
	public void insert(String word) {
		// store root to temp variable
		TrieNode currentNode = root;
		// convert string to char array
		char[] charWord = word.toCharArray();
		// store each character in seperate node
		for (int i = 0; i < charWord.length; i++) {
			// get first character of of a given string
			char ch = charWord[i];
			// character node reference
			TrieNode node = currentNode.getChildren().get(ch);
			if (node == null) {
				// create new node
				node = new TrieNode();
				// put character with new node reference to map object
				currentNode.children.put(ch, node);
			}
			currentNode = node;
		}
		// update endOfWord to true
		currentNode.endOfSring = true;
		log.info("Successfully insert " + word + " into Trie");
	}
	
    /**
     * This method is used for search word in Trie
     * @param searchWord
     * @return
     */
	public Boolean search(String searchWord) {
		// store root to temp variable
		TrieNode currentNode = root;
		// convert string to char array
		char[] charWord = searchWord.toCharArray();
		// store each character in seperate node
		for (int i = 0; i < charWord.length; i++) {
			// get first character of of a given string
			char ch = charWord[i];
			// character node reference
			TrieNode node = currentNode.getChildren().get(ch);
			if (node == null) { // case#1 : if word first character is not exist in Trie
				log.info(searchWord+" word does not exist in Trie");
				return false;
			}
			currentNode = node;
		}
		if(currentNode.getEndOfSring().equals(Boolean.TRUE)) { // case#2 : word found in trie
			log.info(searchWord+" word found in Trie");
		}else { // case#3 : searchWord is prefix of other order then we print not found
			log.info(searchWord+" word not found in Trie");
		}
		// return true for found or false for not found
		return currentNode.getEndOfSring();
	}

}
