package com.tyss.trie.test;

import com.tyss.trie.Trie;

import lombok.extern.java.Log;

@Log
public class TrieTest {
	
	public static void main(String[] args) {
		// create Trie
		Trie trie = new Trie();
		
		// insert value in trie
		log.info("Insert word in Trie");
		trie.insert("air");
		trie.insert("aio");
		
		// search word in Trie
		log.info("Search word in trie");
		Boolean searchResult = trie.search("air");
		log.info(" Search word air isFound::"+searchResult);
		
		Boolean searchResult2 = trie.search("aim");
		log.info(" Search word aim isFound::"+searchResult2);
	}

}
