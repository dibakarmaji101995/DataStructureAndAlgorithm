package com.tyss.recursion;

import java.util.Scanner;

import lombok.extern.java.Log;

@Log
public class CheckTheGivenNumberIsPalindromeNumberOrNotByUsingRecursion {
	private static Integer reverseNum = 0;
	public static void main(String[] args) {
		// create Scanner class object
		Scanner sc = new Scanner(System.in);
		// take the number from keyboard for check it is palindrome number or not
		log.info("Enter any Number to check it is palindrome or not ::");
		Integer number = sc.nextInt();
		Integer temp = number;
		// invoke recursive method to reverse the number
		reverseOfNumber(number);
		// check the given number is same as reverse number
		if (reverseNum.equals(temp)) {
			log.info(temp + " is a Palindrome Number");
		} else {
			log.info(temp + " is not a Palindrome Number ");
		}

	}
	
	public static void reverseOfNumber(Integer number) {
		if(number != 0) {
			Integer lastDigit = number % 10;
			reverseNum = reverseNum * 10 + lastDigit;
			reverseOfNumber(number/10);
		}
	}
}
