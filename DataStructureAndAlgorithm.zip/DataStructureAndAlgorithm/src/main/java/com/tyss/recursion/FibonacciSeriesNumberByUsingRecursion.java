package com.tyss.recursion;

import java.util.Scanner;

import lombok.extern.java.Log;

@Log
public class FibonacciSeriesNumberByUsingRecursion {
	private static Integer firstNum = 0;
	private static Integer secondNum = 1;
	
	public static void main(String[] args) {
		// create Scanner class object
				Scanner sc = new Scanner(System.in);
				// take the number from keyboard for how many numbers of fibonacci series we want print
				log.info("Enter Number location of fibonacci series ::");
				Integer location = sc.nextInt();
				// print/display  fibonacci series
				Integer number = getFibonacciSeriesNumber(location);
				log.info(location+" location Fibonacci Series  number is "+number);
				
	}

	public static Integer getFibonacciSeriesNumber(Integer location) {
		// Base condition/case
		if(location < 1) {
			return 0;
		}else if(location .equals(1) || location.equals(2)) {
			return location-1;
		// recursion condition/case
		}else {
		    return getFibonacciSeriesNumber(location-1) + getFibonacciSeriesNumber(location - 2);	
		}
	}
}
