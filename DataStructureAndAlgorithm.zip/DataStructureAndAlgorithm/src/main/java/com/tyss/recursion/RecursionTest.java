package com.tyss.recursion;

public class RecursionTest {
	public static void main(String[] args) {
		foo(3);

	}
    
	public static void foo(Integer num) {
		if(num<1) { // base condition/case
			return;
		}else { // recursive condition/case
			foo(num-1);
		}
		System.out.println("Some Message "+num);
	}
}
