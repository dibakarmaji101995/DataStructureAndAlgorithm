package com.tyss.recursion;

import java.util.Scanner;

import lombok.extern.java.Log;

@Log
public class FibonacciSeriesByUsingRecursion {
	private static Integer firstNum = 0;
	private static Integer secondNum = 1;
	
	public static void main(String[] args) {
		// create Scanner class object
				Scanner sc = new Scanner(System.in);
				// take the number from keyboard for how many numbers of fibonacci series we want print
				log.info("Enter Number of numbers from fibonacci series ::");
				Integer count = sc.nextInt();
				// print/display  fibonacci series
				System.out.print(firstNum+", "+secondNum+", ");
				printFibonacciSeries(count);
				
	}

	public static void printFibonacciSeries(Integer count) {
		if (count > 2) {
			Integer nextNum = firstNum + secondNum;
			firstNum = secondNum;
			secondNum = nextNum;
			if(count == 3) {
				System.out.print(nextNum);
			}else {
				System.out.print(nextNum+", ");
			}
			printFibonacciSeries(count - 1);
		}
	}
}
