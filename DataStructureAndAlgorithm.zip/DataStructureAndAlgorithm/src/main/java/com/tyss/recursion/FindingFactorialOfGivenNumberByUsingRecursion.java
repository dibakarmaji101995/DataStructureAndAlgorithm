package com.tyss.recursion;

import java.util.Scanner;

import lombok.extern.java.Log;

@Log
public class FindingFactorialOfGivenNumberByUsingRecursion {
	public static void main(String[] args) {
        // create Scanner class object
		Scanner sc = new Scanner(System.in);
		// take the number from keyboard for finding its factorial
		log.info("Enter any Number ::");
		Integer number = sc.nextInt();
		// invoke recursive method to get factorial of given number
		Integer factorial = findFactorial(number);
		// print/ display factorial of given number
		log.info("Factorial of Given Number "+number+" is :: "+factorial);
	}
	
	public static Integer findFactorial(Integer number) {
		Integer factorial = 1;
		if(number.equals(1)) {
			return factorial;
		}else {
			factorial = findFactorial(number-1) * number;
		}
		return factorial;
	}
	
}
