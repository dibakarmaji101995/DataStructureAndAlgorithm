package com.tyss.recursion;

import java.util.Scanner;

import lombok.extern.java.Log;

@Log
public class ReverseOfNumberByUsingRecursion {
	private static Integer temp = 0;
	private static Integer lastDigit = 0;
	private static Integer reverseNum = 0;
	public static void main(String[] args) {
		// create Scanner class object
		Scanner sc = new Scanner(System.in);
		// take the number from keyboard for reverse
		log.info("Enter any Number to check it is palindrome or not ::");
		Integer number = sc.nextInt();
		Integer temp = number;
		// reverse of a number by using recursion
		reverseOfNumber(number);
		log.info("Reverse of a number " + temp + " is :: " + reverseNum);
	}
	
	public static void reverseOfNumber(Integer number) {
		if(number != 0) {
			lastDigit = number % 10;
			reverseNum = reverseNum * 10 +lastDigit;
			reverseOfNumber(number/10);
		}
	}
}
