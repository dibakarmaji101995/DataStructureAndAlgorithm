package com.tyss.tree;

import lombok.Data;
import lombok.extern.java.Log;

@Log
@Data
public class ArrayImplOfBinaryTree {
	private Object[] binaryTree;
	private Integer lastUsedIndex;

	/**
	 * This method is used for create empty Binary Tree
	 * 
	 * @param size
	 */
	public void createBinaryArray(Integer size) {
		// create empty binary tree with given size
		binaryTree = new Object[size];
		// update lastUsedIndex to 0
		lastUsedIndex = 0;
	}

	/**
	 * This method is used for insert value in Binary Tree
	 * 
	 * @param value
	 */
	public void insertValueInBinaryTree(Object value) {
		if (lastUsedIndex >= binaryTree.length) {
			log.info("Binary Tree is Full");
			return;
		} else {
			// insert value at first vacant cell/index
			binaryTree[lastUsedIndex + 1] = value;
			// update lastUsedIndex
			++lastUsedIndex;
			log.info("Insertion is Done!!!!");
		}
	}

	/**
	 * This method is used for search value in Binary Tree
	 * 
	 * @param searchValue
	 * @return
	 */
	public Integer searchValueInBinaryTree(Object searchValue) {
		if (lastUsedIndex > 0) {
			for (int i = 1; i <= lastUsedIndex; i++) {
				if (binaryTree[i].equals(searchValue)) {
					// return index of searchvalue
					return i;
				}
			}
			// return error message as searchValue not found
			return -1;
		}
		// return error message as binary tree is empty
		return 0;

	}

	/**
	 * This method is used for pre-order travrsal of Binary Tree
	 * 
	 * @param index
	 */
	public void preOrderTraversalOfBinaryTree(Integer index) {
		// base case/condition
		if (index > lastUsedIndex) {
			return;
		} else { // recursive case/condition
			// print index value
			System.out.print(binaryTree[index] + " ");
			// recursive call to left sub-tree
			preOrderTraversalOfBinaryTree(index * 2);
			// recursive call to right sub-tree
			preOrderTraversalOfBinaryTree(index * 2 + 1);
		}
	}

	/**
	 * This method is used for in-order travrsal of Binary Tree
	 * 
	 * @param index
	 */
	public void inOrderTraversalOfBinaryTree(Integer index) {
		// base case/condition
		if (index > lastUsedIndex) {
			return;
		} else { // recursive case/condition
			// recursive call to left sub-tree
			preOrderTraversalOfBinaryTree(index * 2);
			// print index value
			System.out.print(binaryTree[index] + " ");
			// recursive call to right sub-tree
			preOrderTraversalOfBinaryTree(index * 2 + 1);
		}
	}

	/**
	 * This method is used for post-order travrsal of Binary Tree
	 * 
	 * @param index
	 */
	public void postOrderTraversalOfBinaryTree(Integer index) {
		// base case/condition
		if (index > lastUsedIndex) {
			return;
		} else { // recursive case/condition
			// recursive call to left sub-tree
			preOrderTraversalOfBinaryTree(index * 2);
			// recursive call to right sub-tree
			preOrderTraversalOfBinaryTree(index * 2 + 1);
			// print index value
			System.out.print(binaryTree[index] + " ");
		}
	}

	/**
	 * This method is used for level-order travrsal of Binary Tree
	 * 
	 * @param index
	 */
	public void levelOrderTraversalOfBinaryTree() {
		// print binary tree
		if (lastUsedIndex > 0) {
			for (int i = 1; i <= lastUsedIndex; i++) {
				System.out.print(binaryTree[i] + " ");
			}
		}
		log.info("Binary Tree is Empty");
	}

	/**
	 * This method is used for delete value in Binary Tree
	 * 
	 * @param deleteValue
	 */
	public void deleteValueInBinaryTree(Object deleteValue) {
		// search deleteValue in binary tree
		Integer searchValueIndex = searchValueInBinaryTree(deleteValue);
		// check deleteValue is present or not
		if (searchValueIndex > 0) {
			// get deepest value in Binary Tree
			Object deepestValue = binaryTree[lastUsedIndex];
			// update deleteValue to deepestValue
			binaryTree[searchValueIndex] = deepestValue;
			// delete deepestvalue
			binaryTree[lastUsedIndex] = null;
			// update lastUsedIndex
			--lastUsedIndex;
		}
	}

	/**
	 * This method is used for delete entire binary tree
	 */
	public void delteEntireBinaryTree() {
		// Nullify binaryTree
		binaryTree = null;
		// update lastUsedIndex to 0
		lastUsedIndex = 0;
	}
}
