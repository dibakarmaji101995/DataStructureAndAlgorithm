package com.tyss.tree.test;

import com.tyss.tree.LinkedListImplOfBinarySearchTree;

import lombok.extern.java.Log;

@Log
public class LinkedListImplOfBinarySearchTreeTest {

	public static void main(String[] args) {

		// create empty BST
		LinkedListImplOfBinarySearchTree bst = LinkedListImplOfBinarySearchTree.createBST();

		// insert value in BST
		bst.insertNodeInBST(100);
		bst.insertNodeInBST(80);
		bst.insertNodeInBST(200);
		bst.insertNodeInBST(70);
		bst.insertNodeInBST(90);
		bst.insertNodeInBST(150);
		bst.insertNodeInBST(300);
		bst.insertNodeInBST(50);
		bst.insertNodeInBST(250);
		bst.insertNodeInBST(400);
		bst.insertNodeInBST(40);
		bst.insertNodeInBST(60);

		// level-order traversal of BST to print all node value
		log.info("Level-Order Traversal After Insert node in BST");
		bst.levelOrderTraversal();

		// print BST in graphically
		bst.printTreeGraphically();

		// search node value in BST and fount it
		log.info("Search Node Value in BST");
		bst.searchNodeInBST(150);

		// search node value in BST and not fount it
		log.info("Search Node value in BST");
		bst.searchNodeInBST(700);

		// delete node in BST (case-2: delete node has 2 children)
		log.info("Delete node in BST (case-2: delete node has 2 children)");
		bst.deleteNodeInBST(100);

		// level-order traversal of BST to print all node value
		log.info("Level-Order Traversal After Insert node in BST");
		bst.levelOrderTraversal();

		// delete node in BST (case-3: delete node has 1 children)
		log.info("Delete node in BST (case-2: delete node has 2 children)");
		bst.deleteNodeInBST(70);

		// level-order traversal of BST to print all node value
		log.info("Level-Order Traversal After Insert node in BST");
		bst.levelOrderTraversal();

		// delete node in BST (case-1: delete node has no children (leaf node))
		log.info("Delete node in BST (case-2: delete node has 2 children)");
		bst.deleteNodeInBST(40);

		// level-order traversal of BST to print all node value
		log.info("Level-Order Traversal After Insert node in BST");
		bst.levelOrderTraversal();

		// print BST in graphically
		bst.printTreeGraphically();

	}
}
