package com.tyss.tree;

import java.util.LinkedList;
import java.util.Queue;

import com.tyss.tree.node.BinaryTreeNode;

import lombok.Data;
import lombok.extern.java.Log;

@Log
@Data
public class LinkedListImplOfBinaryTree {
	private static LinkedListImplOfBinaryTree LINKED_LIST_IMPL_OF_BINARY_TREE;
	private BinaryTreeNode root;

	/**
	 * This method is used for create blank Binary Tree
	 * 
	 * @return
	 */
	public static LinkedListImplOfBinaryTree createBinaryTree() {
		if (LINKED_LIST_IMPL_OF_BINARY_TREE != null) {
			return LINKED_LIST_IMPL_OF_BINARY_TREE;
		} else {
			LINKED_LIST_IMPL_OF_BINARY_TREE = new LinkedListImplOfBinaryTree();
			return LINKED_LIST_IMPL_OF_BINARY_TREE;
		}
	}

	/**
	 * This method is used for insert node in Binary Tree
	 * 
	 * @param value
	 */
	public void insertNodeInBinaryTree(Object value) {
		// create node object
		BinaryTreeNode node = new BinaryTreeNode();
		// initialize node
		node.setValue(value);
		node.setLeft(null);
		node.setRight(null);
		if (root == null) {
			// insert at root
			root = node;
			log.info("Successfully Insertion at Root is Done");
			return;
		}
		// do level-order traversal and find first vacant node

		// create Queue
		Queue<BinaryTreeNode> queue = new LinkedList<>();
		// enqueue rootNode
		queue.add(root);
		// search vacant child
		while (!queue.isEmpty()) {
			// get first node from queue
			BinaryTreeNode firstNode = queue.remove();
			// enqueue first node childs
			if (firstNode.getLeft() == null) {
				// insert at left of first node
				firstNode.setLeft(node);
				log.info("Insertion is Done");
				break;
			} else if (firstNode.getRight() == null) {
				// insert at right of first node
				firstNode.setRight(node);
				log.info("Insertion is Done");
				break;
			} else {
				queue.add(firstNode.getLeft());
				queue.add(firstNode.getRight());
			}

		}

	}

	/**
	 * This method is used for leve order traversal of Binary Tree
	 */
	public void levelOrderTraversal() {
		if (root == null) {
			log.info("Binary Tree is Empty");
			return;
		}
		// create Queue
		Queue<BinaryTreeNode> queue = new LinkedList<BinaryTreeNode>();
		// enqueue root node
		queue.add(root);
		// iterate queue to traversal
		while (!queue.isEmpty()) {
			// dequeue first node of queue
			BinaryTreeNode firstNode = queue.remove();
			// print first node value
			System.out.print(firstNode.getValue() + " ");
			// enqueue first node childs
			if (firstNode.getLeft() != null) {
				// enqueue firstNode left node
				queue.add(firstNode.getLeft());
			}
			if (firstNode.getRight() != null) {
				// enqueue firstNode right node
				queue.add(firstNode.getRight());
			}
		}
	}

	/**
	 * This method is used for pre-order Traversal of Binary Tree
	 * 
	 * @param rootNode
	 */
	public void preOrderTravesal(BinaryTreeNode rootNode) {
		// Base condition/case
		if (rootNode == null) {
			return;
		} else { // Recursive condition/ case
			// print root node value
			System.out.print(rootNode.getValue() + " ");
			// recursive call for left sub-tree
			preOrderTravesal(rootNode.getLeft());
			// recursive call for right sub-tree;
			preOrderTravesal(rootNode.getRight());
		}

	}

	/**
	 * This method is used for in-order Traversal of Binary Tree
	 * 
	 * @param rootNode
	 */
	public void inOrderTravesal(BinaryTreeNode rootNode) {
		// Base condition/case
		if (rootNode == null) {
			return;
		} else { // Recursive condition/ case
			// recursive call for left sub-tree
			inOrderTravesal(rootNode.getLeft());
			// print root node value
			System.out.print(rootNode.getValue() + " ");
			// recursive call for right sub-tree;
			inOrderTravesal(rootNode.getRight());
		}

	}

	/**
	 * This method is used for post-order Traversal of Binary Tree
	 * 
	 * @param rootNode
	 */
	public void postOrderTravesal(BinaryTreeNode rootNode) {
		// Base condition/case
		if (rootNode == null) {
			return;
		} else { // Recursive condition/ case
			// recursive call for left sub-tree
			postOrderTravesal(rootNode.getLeft());
			// recursive call for right sub-tree;
			postOrderTravesal(rootNode.getRight());
			// print root node value
			System.out.print(rootNode.getValue() + " ");
		}

	}

	/**
	 * This method is used for search node value
	 * @param searchValue
	 * @return
	 */
	public Object[] searchValueInBinaryTree(Object searchValue) {
		Object[] result = new Object[2];
		// use level-order traversal to find search value

		// create Queue
		Queue<BinaryTreeNode> queue = new LinkedList<BinaryTreeNode>();
		// enqueue root node in queue
		queue.add(root);
		// iterate to traveling to each node and check its value is searchValue
		while (!queue.isEmpty()) {
			// dequeue first node
			BinaryTreeNode firstNode = queue.remove();
			// check its value is searchValue
			if (firstNode.getValue().equals(searchValue)) {
				result[0] = firstNode; 
				result[1] = true;
				return result;
			}
			// enqueue firstNode child's
			if (firstNode.getLeft() != null) {
				queue.add(firstNode.getLeft());
			}
			if (firstNode.getRight() != null) {
				queue.add(firstNode.getRight());
			}
		}
		// return unsuccessful message
		result[0] = null;
		result[1] = false;
		return result;
	}
	
	/**
	 * This method is used for delete node in binary tree
	 */
	public void deleteNodeInBinaryTree(Object value) {
		// use level order traversal for find out deletable node is there in binary tree or not
		Object[] result = searchValueInBinaryTree(value);
		Boolean isPresent = (Boolean) result[1];
		BinaryTreeNode presentNode = (BinaryTreeNode) result[0];
		if(isPresent.equals(Boolean.TRUE)) {
			// get deepest node in binary tree
			BinaryTreeNode deepestNode = deepestNodeOfBinaryTree();
			// update prsesent node value to deepestNode value
			presentNode.setValue(deepestNode.getValue());
			// delete deepestNode
			deleteDeepestNode(deepestNode);
		}
		
	}
	
	/**
	 * This method is used to delete deepest node
	 * @param deepestNode
	 */
	public void deleteDeepestNode(BinaryTreeNode deepestNode) {
		// create empty queue
		Queue<BinaryTreeNode> queue = new LinkedList<>();
		// enqueue root node
		queue.add(root);
		while (!queue.isEmpty()) {
			// dequeue in queue
			BinaryTreeNode firstNode = queue.remove();
			if(firstNode.getLeft().equals(deepestNode)) {
				firstNode.setLeft(null);
				return;
			}else if(firstNode.getRight().equals(deepestNode)) {
				firstNode.setRight(null);
				return;
			}
			// enqueue firstNode childs
			if(firstNode.getLeft() != null) {
				queue.add(firstNode.getLeft());
			}
			if(firstNode.getRight() != null) {
				queue.add(firstNode.getRight());
			}
		}
	}
	
	/**
	 * This method is used to get deepest node of Binary Tree(get last node of last level of Binary Tree)
	 * @return
	 */
	public BinaryTreeNode deepestNodeOfBinaryTree() {
		BinaryTreeNode firstNode = null;
		// create empty queue
		Queue<BinaryTreeNode> queue = new LinkedList<>();
		// enqueue root node
		queue.add(root);
		//iterate used to go last level of binary tree
		while (!queue.isEmpty()) {
			// dequeue firstNode
			firstNode = queue.remove();
			// enqueue firstNode child's
			if(firstNode.getLeft() != null) {
				queue.add(firstNode.getLeft());
			}
			if(firstNode.getRight() != null) {
				queue.add(firstNode.getRight());
			}
		}
		// return last node of last level of binary tree
		return firstNode;
	}
	
	/**
	 * This method is used for delete Entire Binary Tree
	 */
	public void deleteEntireTree() {
		// nullify root
		root = null;
		log.info("Entire Binary Tree is Deleted");
	}

}
