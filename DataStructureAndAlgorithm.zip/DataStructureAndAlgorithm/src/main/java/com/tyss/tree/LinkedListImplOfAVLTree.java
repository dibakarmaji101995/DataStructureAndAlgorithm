package com.tyss.tree;

import java.util.LinkedList;
import java.util.Queue;

import com.tyss.tree.node.BinaryTreeNode;

import lombok.Data;
import lombok.extern.java.Log;

@Log
@Data
public class LinkedListImplOfAVLTree {
	private static LinkedListImplOfAVLTree linkedListImplOfAVLTree;
	private BinaryTreeNode root;

	public static LinkedListImplOfAVLTree createAVLTree() {
		if (linkedListImplOfAVLTree == null) {
			linkedListImplOfAVLTree = new LinkedListImplOfAVLTree();
			return linkedListImplOfAVLTree;
		} else {
			return linkedListImplOfAVLTree;
		}
	}

	/**
	 * This method is used for search node in AVL Tree
	 * 
	 * @param searchValue
	 */
	public void searchNodeInAVLTree(Object searchValue) {
		searchNodeInAVLTree(root, searchValue);
	}

	/**
	 * This method is used for search node in AVL Tree
	 * 
	 * @param rootNode
	 * @param searchValue
	 * @return
	 */
	public BinaryTreeNode searchNodeInAVLTree(BinaryTreeNode rootNode, Object searchValue) {
		// base case/condition
		if (rootNode == null) {
			return null;
		} else if (searchValue.equals(rootNode.getValue())) {
			return rootNode;
		} else if ((Integer) searchValue <= (Integer) rootNode.getValue()) {
			rootNode.setLeft(searchNodeInAVLTree(rootNode.getLeft(), searchValue));
		} else if ((Integer) searchValue > (Integer) rootNode.getValue()) {
			rootNode.setRight(searchNodeInAVLTree(rootNode.getRight(), searchValue));
		}
		// return rootNode
		return rootNode;
	}

	/**
	 * Level-Order Traversal of AVL Tree for print each node value
	 */
	public void levelOrderTraversal() {
		// create empty queue
		Queue<BinaryTreeNode> queue = new LinkedList<>();
		// enqueue root in q queue
		queue.add(root);
		while (!queue.isEmpty()) {
			// dequeue first Node
			BinaryTreeNode firstNode = queue.remove();
			// print firstNode value
			System.out.print(firstNode.getValue() + " ");
			// enqueue firstNode childs in queue
			if (firstNode.getLeft() != null) {
				queue.add(firstNode.getLeft());
			}
			if (firstNode.getRight() != null) {
				queue.add(firstNode.getRight());
			}
		}
	}

	public void insertNodeInAVLTree(Object insertValue) {
		root = insertNodeInAVLTree(root, insertValue);
	}
	
	public BinaryTreeNode insertNodeInAVLTree(BinaryTreeNode rootNode, Object insertValue) {
		// BST Logic
		// base case/condition
		if (rootNode == null) {
			// insert at root
			// create empty node object
			BinaryTreeNode node = new BinaryTreeNode();
			// initialize node value as insertValue
			node.setValue(insertValue);
			node.setHeight(0);
			// retuen node
			return node;
			// recursive case/condition
		} else if ((Integer) insertValue <= (Integer) rootNode.getValue()) {
			rootNode.setLeft(insertNodeInAVLTree(rootNode.getLeft(), insertValue));
		} else if ((Integer) insertValue > (Integer)rootNode.getValue()) {
			rootNode.setRight(insertNodeInAVLTree(rootNode.getRight(), insertValue));
		}
		
		// AVL Tree Rotation Logic
		int balance = checkBalance(rootNode.getLeft(), rootNode.getRight());
		if (balance > 1) {
			if (checkBalance(rootNode.getLeft().getLeft(), rootNode.getLeft().getRight()) > 0) {
				rootNode = rightRotate(rootNode);// LL Condition
			} else {
				rootNode.setLeft(leftRotate(rootNode.getLeft())); // LR Condition
				rootNode = rightRotate(rootNode);
			}
		} else if (balance < -1) {
			if (checkBalance(rootNode.getRight().getRight(), rootNode.getRight().getLeft()) > 0) {
				rootNode = leftRotate(rootNode);// RR Condition

			} else {
				rootNode.setRight(rightRotate(rootNode.getRight()));// RL Condition
				rootNode = leftRotate(rootNode);

			}
		}

		if (rootNode.getLeft() != null) {
			rootNode.getLeft().setHeight(calculateHeight(rootNode.getLeft()));
		}
		if (rootNode.getRight() != null) {
			rootNode.getRight().setHeight(calculateHeight(rootNode.getRight()));
		}
		rootNode.setHeight(calculateHeight(rootNode));
		return rootNode;
	}

    // Helper Method
	private BinaryTreeNode leftRotate(BinaryTreeNode currentNode) {
		BinaryTreeNode newRoot = currentNode.getRight();
		currentNode.setRight(currentNode.getRight().getLeft());
		newRoot.setLeft(currentNode);
		currentNode.setHeight(calculateHeight(currentNode));
		newRoot.setHeight(calculateHeight(newRoot));
		return newRoot;
	}// end of method

    // Helper Method
	private BinaryTreeNode rightRotate(BinaryTreeNode currentNode) {
		BinaryTreeNode newRoot = currentNode.getLeft();
		currentNode.setLeft(currentNode.getLeft().getRight());
		newRoot.setRight(currentNode);
		currentNode.setHeight(calculateHeight(currentNode));
		newRoot.setHeight(calculateHeight(newRoot));
		return newRoot;
	}// end of method

    // Helper Method
	private int checkBalance(BinaryTreeNode rootLeft, BinaryTreeNode rootRight) {
		if ((rootLeft == null) && (rootRight == null)) { // if current node is a leaf node then no need to check balance
															// of its children
			return 0;
		} else if (rootLeft == null) {
			return -1 * (rootRight.getHeight() + 1); // if left node node is not there then simply return right node's
														// height + 1
														// we need to make it -1 because blank height is considered
														// having height as '-1'
		} else if (rootRight == null) {
			return rootLeft.getHeight() + 1;
		} else {
			return rootLeft.getHeight() - rootRight.getHeight(); // +1 is not required, as both right and left child
																	// exits and 1 gets nullified
		}
	}// end of method

    // Calculate height of Node
	private int calculateHeight(BinaryTreeNode currentNode) {
		if (currentNode == null) {
			return 0;
		}
		return 1 + Math.max((currentNode.getLeft() != null ? currentNode.getLeft().getHeight() : -1),
				(currentNode.getRight() != null ? currentNode.getRight().getHeight() : -1));

	}// end of method
	
	public void deleteNodeInBST(Object deleteValue) {
		deleteNodeOfBST(root, deleteValue);
	}
	
	// Helper Method for delete
		public BinaryTreeNode deleteNodeOfBST(BinaryTreeNode currentNode, Object value) {
			// THIS ELSE_IF BLOCK IS BST CONDITION
			if (currentNode == null)
				return null;
			if ((Integer)value < (Integer)currentNode.getValue()) {
				currentNode.setLeft(deleteNodeOfBST(currentNode.getLeft(), value));
			} else if ((Integer)value > (Integer)currentNode.getValue()) {
				currentNode.setRight(deleteNodeOfBST(currentNode.getRight(), value));
			} else { // If currentNode is the node to be deleted
				//System.out.println("currentNode is the node to be deleted");
				if (currentNode.getLeft() != null && currentNode.getRight() != null) { // if nodeToBeDeleted have both children
					BinaryTreeNode temp = currentNode;
					BinaryTreeNode minNodeForRight = minimumElement(temp.getRight());// Finding minimum element from right subtree
					currentNode.setValue(minNodeForRight.getValue()); // Replacing current node with minimum node from right subtree
					deleteNodeOfBST(currentNode.getRight(), minNodeForRight.getValue());// Deleting minimum node from right now
				} else if (currentNode.getLeft() != null) {// if nodeToBeDeleted has only left child
					currentNode = currentNode.getLeft();
				} else if (currentNode.getRight() != null) {// if nodeToBeDeleted has only right child
					currentNode = currentNode.getRight();
				} else { // if nodeToBeDeleted do not have child (Leaf node)
					//System.out.println("This node is leaf node");
					currentNode = null;
				}
				return currentNode;// if it is a leaf node,then no need to do balancing for this node, do only for its ancestors
			}

			// THIS IS WHERE WE WILL DO AVL SPECIFIC WORK
			int balance = checkBalance(currentNode.getLeft(), currentNode.getRight());
			if (balance > 1) {
				if (checkBalance(currentNode.getLeft().getLeft(), currentNode.getLeft().getRight()) > 0) {
					currentNode = rightRotate(currentNode);// LL Condition
				} else {
					currentNode.setLeft(leftRotate(currentNode.getLeft())); // LR Condition
					currentNode = rightRotate(currentNode);
				}
			} else if (balance < -1) {
				if (checkBalance(currentNode.getRight().getRight(), currentNode.getRight().getLeft()) > 0) {
					currentNode = leftRotate(currentNode);// RR Condition
				} else {
					currentNode.setRight(rightRotate(currentNode.getRight()));// RL Condition
					currentNode = leftRotate(currentNode);
				}
			}

			if (currentNode.getLeft() != null) {
				currentNode.getLeft().setHeight(calculateHeight(currentNode.getLeft()));
			}
			if (currentNode.getRight() != null) {
				currentNode.getRight().setHeight(calculateHeight(currentNode.getRight()));
			}
			currentNode.setHeight(calculateHeight(currentNode));
			return currentNode;

		}// end of method

		
		// Get minimum element in binary search tree
		public  BinaryTreeNode minimumElement(BinaryTreeNode root) {
			if (root.getLeft() == null)
				return root;
			else {
				return minimumElement(root.getLeft());
			}
		}// end of method
		
		/*
		 * This method is used for print BST in Graphically
		 */
		public void printTreeGraphically() {
			Queue<BinaryTreeNode> queue = new LinkedList<BinaryTreeNode>();
			Queue<Integer> level = new LinkedList<Integer>();

			int CurrentLevel = 1;
			boolean previousLevelWasAllNull = false;
			queue.add(root);
			level.add(1);

			System.out.println("\nPrinting Level order traversal of Tree...");
			if (root == null) {
				System.out.println("Tree does not exists !");
				return;
			}

			while (!queue.isEmpty()) {
				if (CurrentLevel == level.peek()) { // if we are in the same level
					if (queue.peek() == null) {
						queue.add(null);
						level.add(CurrentLevel + 1);
					} else {
						queue.add(queue.peek().getLeft());
						level.add(CurrentLevel + 1);
						queue.add(queue.peek().getRight());
						level.add(CurrentLevel + 1);
						previousLevelWasAllNull = false;
					}
					System.out.print(queue.remove() + "  ");
					level.remove();
				} else { // level has changed
					System.out.println("\n");
					CurrentLevel++;
					if (previousLevelWasAllNull == true) {
						break;
					}
					previousLevelWasAllNull = true;
				}
			} // end of loop
		}// end of method
		
		/**
		 * This method is used for search node in BST
		 * 
		 * @param searchValue
		 * @return
		 */
		public void searchNodeInBST(Object searchValue) {
			 searchNodeInBST(root, searchValue);
		}
		
		/**
		 * This method is used for search node in BST
		 * 
		 * @param rootNode
		 * @param searchValue
		 * @return
		 */
		public BinaryTreeNode searchNodeInBST(BinaryTreeNode rootNode, Object searchValue) {
			// Base case/condition
			if (rootNode == null) {
				log.info(searchValue + " not found in BST");
				return null;
			} else if (searchValue.equals(rootNode.getValue())) {
				log.info(searchValue + " found in BST");
				return rootNode;
			} else if ((Integer) searchValue < (Integer) rootNode.getValue()) { // recursive case/condition
				rootNode.setLeft(searchNodeInBST(rootNode.getLeft(), searchValue));
			} else if ((Integer) searchValue > (Integer) rootNode.getValue()) {
				rootNode.setRight(searchNodeInBST(rootNode.getRight(), searchValue));
			}
			return rootNode;
		}
}
