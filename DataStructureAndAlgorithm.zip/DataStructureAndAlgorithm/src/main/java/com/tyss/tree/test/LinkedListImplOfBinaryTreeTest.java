package com.tyss.tree.test;

import com.tyss.tree.LinkedListImplOfBinaryTree;

import lombok.extern.java.Log;

@Log
public class LinkedListImplOfBinaryTreeTest {
	public static void main(String[] args) {
		// create empty Binary Tree
		LinkedListImplOfBinaryTree binaryTree = LinkedListImplOfBinaryTree.createBinaryTree();

		// insert 10 elements in binary tree
		for (int i = 0; i < 10; i++) {
			binaryTree.insertNodeInBinaryTree(i + 10);
		}

		// level-order traversal of binary tree
		log.info("Level-Order Traversal of Binary Tree");
		binaryTree.levelOrderTraversal();

		// pre-order traversal of binary tree
		log.info("Pre-Order Traversal of Binary Tree");
		binaryTree.preOrderTravesal(binaryTree.getRoot());

		// In-order traversal of binary tree
		log.info("In-Order Traversal of Binary Tree");
		binaryTree.inOrderTravesal(binaryTree.getRoot());

		// post-order traversal of binary tree
		log.info("Post-Order Traversal of Binary Tree");
		binaryTree.postOrderTravesal(binaryTree.getRoot());

		// search 10 in binary tree and found it
		log.info("Search 10 in Binary Tree");
		Object[] isPresent = binaryTree.searchValueInBinaryTree(10);
		log.info("10 is present in Binary Tee ::" + isPresent[0]);

		// search 100 in binary tree and not found it
		log.info("Search 10 in Binary Tree");
		Object[] isPresent2 = binaryTree.searchValueInBinaryTree(100);
		log.info("100 is found in Binary Tree?" + isPresent[1]);

		// delete node in binary tree
		log.info("Delete node in Binary Tree");
		binaryTree.deleteNodeInBinaryTree(10);

		// level-order traversal to print all node value after delete node in binary
		// tree
		log.info("Level-Order Traversal of Binary Tree");
		binaryTree.levelOrderTraversal();

		// delete entire Binary Tree
		log.info("Delete entire Binary Tree");
		binaryTree.deleteEntireTree();

		// level-order traversal to print all node value after delete node in binary
		// tree
		log.info("Level-Order Traversal of Binary Tree");
		binaryTree.levelOrderTraversal();
	}
}
