package com.tyss.tree.test;

import com.tyss.tree.ArrayImplOfBinaryTree;

import lombok.extern.java.Log;

@Log
public class ArrayImplOfBinaryTreeTest {

	public static void main(String[] args) {
		// create ArrayImplOfBinaryTree class object
		ArrayImplOfBinaryTree binaryTree = new ArrayImplOfBinaryTree();

		// create empty binary tree
		binaryTree.createBinaryArray(20);

		// insert 10 value in binary tree
		for (int i = 0; i < 10; i++) {
			binaryTree.insertValueInBinaryTree(i + 10);
		}

		// level-order traversal of Binary Tree
		log.info("Level-Order Traversal after Insertion");
		binaryTree.levelOrderTraversalOfBinaryTree();

		// search value in Binary Tree and found it
		log.info("Search value in Binary Tree and fount it");
		Integer searchvalueindex = binaryTree.searchValueInBinaryTree(14);
		if (searchvalueindex.equals(0)) {
			log.info("Binary Tree is Empty");
		} else if (searchvalueindex.equals(-1)) {
			log.info("14 is not found ");
		} else {
			log.info("14 is found in index " + searchvalueindex);
		}

		// search value in Binary Tree and not found it
		log.info("Search value in Binary Tree and fount it");
		Integer searchvalueindex2 = binaryTree.searchValueInBinaryTree(140);
		if (searchvalueindex.equals(0)) {
			log.info("Binary Tree is Empty");
		} else if (searchvalueindex2.equals(-1)) {
			log.info("140 is not found");
		} else {
			log.info("140 is found in index " + searchvalueindex2);
		}

		// pre-order traversal of Binary Tree
		log.info("Pre-Order Traversal after Insertion");
		binaryTree.preOrderTraversalOfBinaryTree(1);

		// in-order traversal of Binary Tree
		log.info("In-Order Traversal after Insertion");
		binaryTree.inOrderTraversalOfBinaryTree(1);

		// post-order traversal of Binary Tree
		log.info("Post-Order Traversal after Insertion");
		binaryTree.postOrderTraversalOfBinaryTree(1);

		// level-order traversal of Binary Tree
		log.info("Level-Order Traversal");
		binaryTree.levelOrderTraversalOfBinaryTree();

		// delete value in Binary Tree
		log.info("Delete value in Binary Tree");
		binaryTree.deleteValueInBinaryTree(10);

		// level-order traversal of Binary Tree after delete value
		log.info("Level-Order Traversal after delete value");
		binaryTree.levelOrderTraversalOfBinaryTree();

		// delete entire Binary Tree
		log.info("Delete entire Binary Tree");
		binaryTree.delteEntireBinaryTree();

		// level-order traversal of Binary Tree after delete entire binary tree
		log.info("Level-Order Traversal after delete entire tree");
		binaryTree.levelOrderTraversalOfBinaryTree();

	}
}
