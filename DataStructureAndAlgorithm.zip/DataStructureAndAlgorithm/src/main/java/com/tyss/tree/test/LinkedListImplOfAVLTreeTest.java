package com.tyss.tree.test;

import com.tyss.tree.LinkedListImplOfAVLTree;
import com.tyss.tree.LinkedListImplOfBinarySearchTree;

import lombok.extern.java.Log;

@Log
public class LinkedListImplOfAVLTreeTest {

	public static void main(String[] args) {

		// create empty BST
		LinkedListImplOfAVLTree avlt = LinkedListImplOfAVLTree.createAVLTree();

		// insert value in BST
		avlt.insertNodeInAVLTree(100);
		avlt.insertNodeInAVLTree(80);
		avlt.insertNodeInAVLTree(200);
		avlt.insertNodeInAVLTree(70);
		avlt.insertNodeInAVLTree(90);
		avlt.insertNodeInAVLTree(150);
		avlt.insertNodeInAVLTree(300);
		avlt.insertNodeInAVLTree(50);
		avlt.insertNodeInAVLTree(250);
		avlt.insertNodeInAVLTree(400);
		avlt.insertNodeInAVLTree(40);
		avlt.insertNodeInAVLTree(60);

		// level-order traversal of BST to print all node value
		log.info("Level-Order Traversal After Insert node in BST");
		avlt.levelOrderTraversal();

		// print BST in graphically
		avlt.printTreeGraphically();

		// search node value in BST and fount it
		log.info("Search Node Value in BST");
		avlt.searchNodeInBST(150);

		// search node value in BST and not fount it
		log.info("Search Node value in BST");
		avlt.searchNodeInBST(700);

		// delete node in BST (case-2: delete node has 2 children)
		log.info("Delete node in BST (case-2: delete node has 2 children)");
		avlt.deleteNodeInBST(100);

		// level-order traversal of BST to print all node value
		log.info("Level-Order Traversal After Insert node in BST");
		avlt.levelOrderTraversal();

		// delete node in BST (case-3: delete node has 1 children)
		log.info("Delete node in BST (case-2: delete node has 2 children)");
		avlt.deleteNodeInBST(70);

		// level-order traversal of BST to print all node value
		log.info("Level-Order Traversal After Insert node in BST");
		avlt.levelOrderTraversal();

		// delete node in BST (case-1: delete node has no children (leaf node))
		log.info("Delete node in BST (case-2: delete node has 2 children)");
		avlt.deleteNodeInBST(40);

		// level-order traversal of BST to print all node value
		log.info("Level-Order Traversal After Insert node in BST");
		avlt.levelOrderTraversal();

		// print BST in graphically
		avlt.printTreeGraphically();

	}
}
