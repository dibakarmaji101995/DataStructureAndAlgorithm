package com.tyss.tree.node;

import lombok.Data;

@Data
public class BinaryTreeNode {
      private Object value;
      private BinaryTreeNode left;
      private BinaryTreeNode right;
      private Integer height;
}
