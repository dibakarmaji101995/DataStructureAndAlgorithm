package com.tyss.tree;

import java.util.LinkedList;
import java.util.Queue;

import com.tyss.tree.node.BinaryTreeNode;

import lombok.Data;
import lombok.extern.java.Log;

@Log
@Data
public class LinkedListImplOfBinarySearchTree {
	private static LinkedListImplOfBinarySearchTree linkedListImplOfBinarySearchTree;
	private BinaryTreeNode root;

	/**
	 * This method is used for create empty BST
	 * 
	 * @return
	 */
	public static LinkedListImplOfBinarySearchTree createBST() {
		if (linkedListImplOfBinarySearchTree == null) {
			linkedListImplOfBinarySearchTree = new LinkedListImplOfBinarySearchTree();
			return linkedListImplOfBinarySearchTree;
		} else {
			return linkedListImplOfBinarySearchTree;
		}
	}

	/**
	 * This method is used for search node in BST
	 * 
	 * @param searchValue
	 * @return
	 */
	public void searchNodeInBST(Object searchValue) {
		 searchNodeInBST(root, searchValue);
	}

	/**
	 * This method is used for search node in BST
	 * 
	 * @param rootNode
	 * @param searchValue
	 * @return
	 */
	public BinaryTreeNode searchNodeInBST(BinaryTreeNode rootNode, Object searchValue) {
		// Base case/condition
		if (rootNode == null) {
			log.info(searchValue + " not found in BST");
			return null;
		} else if (searchValue.equals(rootNode.getValue())) {
			log.info(searchValue + " found in BST");
			return rootNode;
		} else if ((Integer) searchValue < (Integer) rootNode.getValue()) { // recursive case/condition
			rootNode.setLeft(searchNodeInBST(rootNode.getLeft(), searchValue));
		} else if ((Integer) searchValue > (Integer) rootNode.getValue()) {
			rootNode.setRight(searchNodeInBST(rootNode.getRight(), searchValue));
		}
		return rootNode;
	}

	/**
	 * This method is used for insert node in BST
	 * 
	 * @param insertValue
	 * @return
	 */
	public void insertNodeInBST(Object insertValue) {
		root = insertNodeInBST(root, insertValue);
	}

	/**
	 * This method is used for insert node in BST
	 * 
	 * @param rootNode
	 * @param insertValue
	 * @return
	 */
	private BinaryTreeNode insertNodeInBST(BinaryTreeNode rootNode, Object insertValue) {
		// base case/condition
		if (rootNode == null) {
			// insert node in root
			// create empty node
			BinaryTreeNode node = new BinaryTreeNode();
			node.setValue(insertValue);
			// store node reference to rootNode
			rootNode = node;
			log.info("Successfully insert node in BST");
		} else if ((Integer) insertValue <= (Integer) rootNode.getValue()) { // insert node in non empty BST
			rootNode.setLeft(insertNodeInBST(rootNode.getLeft(), insertValue));
		} else if ((Integer) insertValue > (Integer) rootNode.getValue()) {
			rootNode.setRight(insertNodeInBST(rootNode.getRight(), insertValue));
		}
		return rootNode;
	}

	/**
	 * This method is used for delete node in BST
	 * 
	 * @param deleteValue
	 * @return
	 */
	public BinaryTreeNode deleteNodeInBST(Object deleteValue) {
		return deleteNodeInBST(root, deleteValue);
	}

	/**
	 * This method is used for delete node in BST
	 * 
	 * @param rootNode
	 * @param deleteValue
	 * @return
	 */
	private BinaryTreeNode deleteNodeInBST(BinaryTreeNode rootNode, Object deleteValue) {
		// base case/condition
		if (rootNode == null) {
			return null;
		} else if ((Integer) deleteValue < (Integer) rootNode.getValue()) { // recursive case/condition
			rootNode.setLeft(deleteNodeInBST(rootNode.getLeft(), deleteValue));
		} else if ((Integer) deleteValue > (Integer) rootNode.getValue()) {
			rootNode.setRight(deleteNodeInBST(rootNode.getRight(), deleteValue));
		} else // deleteNode
		if (rootNode.getLeft() != null && rootNode.getRight() != null) { // case-2
			// get minimum value node from right sub-tree
			BinaryTreeNode minimumValueNode = getMinimumValueNodeOfBST(rootNode.getRight());
			// update deleteNode value to minimum value
			rootNode.setValue(minimumValueNode.getValue());
			// delete minimumValueNode in BST
			rootNode.setRight(deleteNodeInBST(rootNode.getRight(), minimumValueNode.getValue()));

		} else if (rootNode.getRight() == null) { // case-3
			rootNode = rootNode.getLeft();
		} else if (rootNode.getLeft() == null) {
			rootNode = rootNode.getRight();
		} else { // case-1
			rootNode = null;
		}
		// return rootNode
		return rootNode;
	}

	/**
	 * This method is used for get minimum value node in BST
	 * 
	 * @param rootNode
	 * @return
	 */
	public BinaryTreeNode getMinimumValueNodeOfBST(BinaryTreeNode rootNode) {
		// base case
		if (rootNode.getLeft() == null) {
			return rootNode;
		} else { // recursive case
			return getMinimumValueNodeOfBST(rootNode.getLeft());
		}
	}

	/**
	 * This method is used for level-order traversal of BST
	 */
	public void levelOrderTraversal() {
		// create empty queue
		Queue<BinaryTreeNode> queue = new LinkedList<>();
		// enqueue root node
		queue.add(root);
		while (!queue.isEmpty()) {
			// dequeue firstNode
			BinaryTreeNode firstNode = queue.remove();
			// print deuqueue node value
			System.out.print(firstNode.getValue() + " ");
			// enqueue firstNode childs
			if (firstNode.getLeft() != null) {
				queue.add(firstNode.getLeft());
			}
			if (firstNode.getRight() != null) {
				queue.add(firstNode.getRight());
			}
		}
	}

	/*
	 * This method is used for print BST in Graphically
	 */
	public void printTreeGraphically() {
		Queue<BinaryTreeNode> queue = new LinkedList<BinaryTreeNode>();
		Queue<Integer> level = new LinkedList<Integer>();

		int CurrentLevel = 1;
		boolean previousLevelWasAllNull = false;
		queue.add(root);
		level.add(1);

		System.out.println("\nPrinting Level order traversal of Tree...");
		if (root == null) {
			System.out.println("Tree does not exists !");
			return;
		}

		while (!queue.isEmpty()) {
			if (CurrentLevel == level.peek()) { // if we are in the same level
				if (queue.peek() == null) {
					queue.add(null);
					level.add(CurrentLevel + 1);
				} else {
					queue.add(queue.peek().getLeft());
					level.add(CurrentLevel + 1);
					queue.add(queue.peek().getRight());
					level.add(CurrentLevel + 1);
					previousLevelWasAllNull = false;
				}
				System.out.print(queue.remove() + "  ");
				level.remove();
			} else { // level has changed
				System.out.println("\n");
				CurrentLevel++;
				if (previousLevelWasAllNull == true) {
					break;
				}
				previousLevelWasAllNull = true;
			}
		} // end of loop
	}// end of method
}
