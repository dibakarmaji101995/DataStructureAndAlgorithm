package com.tyss.linkedlist.test;

import java.util.Scanner;

import com.tyss.linkedlist.CircularSingleLinkedList;
import com.tyss.linkedlist.node.SingleLinkedListNode;

import lombok.extern.java.Log;

@Log
public class CircularSingleLinkedListTest {

	public static void main(String[] args) {
		// create Scanner class object
		Scanner sc = new Scanner(System.in);
		// take first and second node value from keyboard
		log.info("Enter first node value ::");
		Integer firstNodeValue = sc.nextInt();

		// create Circular SingleLinkedList object
		CircularSingleLinkedList csll = new CircularSingleLinkedList();
		// initialize default value of SingleLinkedList fields
		csll.setSize(0);
		csll.setHead(null);
		csll.setTail(null);

		// create Single Linked List
		csll.createSingleLinkedList(firstNodeValue);
		log.info("First node Value is " + csll.getHead().getValue());
		log.info("First node reference is " + csll.getHead().getNext());
		log.info("Circular Single Linked List Creation is Done!!!!");

		// insert new node at start of SLL
		log.info("Enter new node value for inserting new node at start of CSLL ::");
		Integer newNodeValue = sc.nextInt();
		log.info("Enter start location ::");
		Integer location = sc.nextInt();

		// invoke insertNewNode(-,-,-,-,-) method to insert new node at start of SLL
		csll.insertNewNode(newNodeValue, location);
		// print all node value
		SingleLinkedListNode tempNode = csll.getHead();
		for (int i = 0; i < csll.getSize(); i++) {
			log.info((i + 1) + " node value is " + tempNode.getValue());
			tempNode = (SingleLinkedListNode) tempNode.getNext();
		}

		// insert new node at end of SLL
		log.info("Enter new node value for inserting new node at end of CSLL ::");
		Integer newNodeValue2 = sc.nextInt();
		log.info("Enter end location ::");
		Integer location2 = sc.nextInt();

		// invoke insertNewNode(-,-,-,-,-) method to insert new node at end of CSLL
		csll.insertNewNode(newNodeValue2, location2);
		// print all node value
		SingleLinkedListNode tempNode2 = csll.getHead();
		for (int i = 0; i < csll.getSize(); i++) {
			log.info((i + 1) + " node value is " + tempNode2.getValue());
			tempNode2 = (SingleLinkedListNode) tempNode2.getNext();
		}

		// insert new node at any specific location of SLL
		log.info("Enter new node value for inserting new node at any specific location of SLL ::");
		Integer newNodeValue3 = sc.nextInt();
		log.info("Enter any specific location ::");
		Integer location3 = sc.nextInt();

		// invoke insertNewNode(-,-,-,-,-) method to insert new node at any specific
		// location of CSLL
		csll.insertNewNode(newNodeValue3, location3);
		// print all node value
		SingleLinkedListNode tempNode3 = csll.getHead();
		for (int i = 0; i < csll.getSize(); i++) {
			log.info((i + 1) + " node value is " + tempNode3.getValue());
			tempNode3 = (SingleLinkedListNode) tempNode3.getNext();
		}
		log.info("Insertion is Done!!!");
		log.info("Last node next value is "+csll.getTail().getNext());

		// Traversal Circular Single Linked List for print all node value
		csll.traversalOfSingleLinkedList();

		// search node in Circular Single Linked List
		log.info("Enter Search Node Value ::");
		Integer searchNodeValue = sc.nextInt();
		// invoke searchNode(-) method
		Integer searchNodeLocation = csll.searchNode(searchNodeValue);
		if (searchNodeLocation.equals(-1)) {
			log.info("Search Node is Not found in the given Circular Single Linked List");
		} else {
			log.info("Search Node value found in Node-" + searchNodeLocation);
		}

		// delete start node in SLL
		log.info("Enter start location for delete ::");
		Integer startNodeLocation = sc.nextInt();
		// invoke searchNode(-) method
		csll.deleteNode(startNodeLocation);
		// print all node value after delete node
		csll.traversalOfSingleLinkedList();

		// delete start node in SLL
		log.info("Enter end location for delete ::");
		Integer endNodeLocation = sc.nextInt();
		// invoke searchNode(-) method
		csll.deleteNode(endNodeLocation);
		// print all node value after delete node
		csll.traversalOfSingleLinkedList();

		// delete specific node in SLL
		log.info("Enter specific location for delete ::");
		Integer specificNodeLocation = sc.nextInt();
		// invoke searchNode(-) method
		csll.deleteNode(specificNodeLocation);
		// print all node value after delete node
		csll.traversalOfSingleLinkedList();

		// delete entire Circular SingleLinkedList
		csll.deleteEntireSingleLinkedList();
		// print all node value after delete node
		csll.traversalOfSingleLinkedList();
	}
}
