package com.tyss.linkedlist.test;

import java.util.Scanner;

import com.tyss.linkedlist.CircularDoubleLinkedList;
import com.tyss.linkedlist.CircularSingleLinkedList;
import com.tyss.linkedlist.DoubleLinkedList;
import com.tyss.linkedlist.node.DoubleLinkedListNode;
import com.tyss.linkedlist.node.SingleLinkedListNode;

import lombok.extern.java.Log;

@Log
public class CircularDoubleLinkedListTest {

	public static void main(String[] args) {
		// create Scanner class object
		Scanner sc = new Scanner(System.in);
		// take first and second node value from keyboard
		log.info("Enter first node value ::");
		Integer firstNodeValue = sc.nextInt();

		// create CircularLinkedList object
		CircularDoubleLinkedList dll = new CircularDoubleLinkedList();
		// initialize default value of SingleLinkedList fields
		dll.setSize(0);
		dll.setHead(null);
		dll.setTail(null);

		// invoke createDoubleLinkedList(-) to create DLL with start node
		dll.createDoubleLinkedList(firstNodeValue);
		log.info("First node Value is " + dll.getHead().getValue());
		log.info("First node next reference is " + dll.getHead().getNext());
		log.info("First node previous reference is " + dll.getHead().getNext());
		log.info("Circular Double Linked List Creation is Done!!!!");

		// insert new node at start of SLL
		log.info("Enter new node value for inserting new node at start of CDLL ::");
		Integer newNodeValue = sc.nextInt();
		log.info("Enter start location ::");
		Integer location = sc.nextInt();

		// invoke insertNewNode(-,-,-,-,-) method to insert new node at start of CDLL
		dll.insertNewNode(newNodeValue, location);
		// print all node value
		DoubleLinkedListNode tempNode = dll.getHead();
		for (int i = 0; i < dll.getSize(); i++) {
			log.info((i + 1) + " node value is " + tempNode.getValue());
			tempNode = (DoubleLinkedListNode) tempNode.getNext();
		}

		// insert new node at end of DLL
		log.info("Enter new node value for inserting new node at end of CDLL ::");
		Integer newNodeValue2 = sc.nextInt();
		log.info("Enter end location ::");
		Integer location2 = sc.nextInt();

		// invoke insertNewNode(-,-,-,-,-) method to insert new node at end of CDLL
		dll.insertNewNode(newNodeValue2, location2);
		// print all node value
		DoubleLinkedListNode tempNode2 = dll.getHead();
		for (int i = 0; i < dll.getSize(); i++) {
			log.info((i + 1) + " node value is " + tempNode2.getValue());
			tempNode2 = (DoubleLinkedListNode) tempNode2.getNext();
		}

		// insert new node at any specific location of DLL
		log.info("Enter new node value for inserting new node at any specific location of CDLL ::");
		Integer newNodeValue3 = sc.nextInt();
		log.info("Enter any specific location ::");
		Integer location3 = sc.nextInt();

		// invoke insertNewNode(-,-,-,-,-) method to insert new node at any specific
		// location of CDLL
		dll.insertNewNode(newNodeValue3, location3);
		// print all node value
		DoubleLinkedListNode tempNode3 = dll.getHead();
		for (int i = 0; i < dll.getSize(); i++) {
			log.info((i + 1) + " node value is " + tempNode3.getValue());
			tempNode3 = (DoubleLinkedListNode) tempNode3.getNext();
		}
		log.info("Insertion is Done!!!");
		log.info("Last node next value is "+dll.getTail().getNext());
		log.info("First node previous value is "+dll.getHead().getPrevious());

		// Traversal Circular Double Linked List for print all node value
		dll.traversalOfDoubleLinkedList();
		
		// Reverse traversal of Circular Double Linked List
		dll.reverseTraversalOfDoubleLinkedList();
		
		// search node in Circular Double Linked List
		log.info("Enter Search Node Value ::");
		Integer searchNodeValue = sc.nextInt();
		// invoke searchNode(-) method
		Integer searchNodeLocation = dll.searchNode(searchNodeValue);
		if (searchNodeLocation.equals(-1)) {
			log.info("Search Node is Not found in the given Circular Double Linked List");
		} else {
			log.info("Search Node value found in Node-" + searchNodeLocation);
		}

		// delete start node in CDLL
		log.info("Enter start location for delete ::");
		Integer startNodeLocation = sc.nextInt();
		// invoke searchNode(-) method
		dll.deleteNode(startNodeLocation);
		// print all node value after delete node
		dll.traversalOfDoubleLinkedList();
		log.info("Last node next value is "+dll.getTail().getNext());
		log.info("First node previous value is "+dll.getHead().getPrevious());

		// delete end node in CDLL
		log.info("Enter end location for delete ::");
		Integer endNodeLocation = sc.nextInt();
		// invoke searchNode(-) method
		dll.deleteNode(endNodeLocation);
		// print all node value after delete node
		dll.traversalOfDoubleLinkedList();
		log.info("Last node next value is "+dll.getTail().getNext());
		log.info("First node previous value is "+dll.getHead().getPrevious());

		// delete specific node in CDLL
		log.info("Enter specific location for delete ::");
		Integer specificNodeLocation = sc.nextInt();
		// invoke searchNode(-) method
		dll.deleteNode(specificNodeLocation);
		// print all node value after delete node
		dll.traversalOfDoubleLinkedList();
		log.info("Last node next value is "+dll.getTail().getNext());
		log.info("First node previous value is "+dll.getHead().getPrevious());

		// delete entire Circular SingleLinkedList
		dll.deleteEntireSingleLinkedList();
		// print all node value after delete node
		dll.traversalOfDoubleLinkedList(); 
	}
}
