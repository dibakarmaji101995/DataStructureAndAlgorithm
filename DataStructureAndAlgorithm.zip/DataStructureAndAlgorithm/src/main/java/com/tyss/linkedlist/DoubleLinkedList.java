package com.tyss.linkedlist;

import com.tyss.linkedlist.node.DoubleLinkedListNode;
import com.tyss.linkedlist.node.SingleLinkedListNode;
import com.tyss.linkedlist.node.SingleLinkedListNode;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.java.Log;

@Log
@Data
public class DoubleLinkedList {

	private DoubleLinkedListNode head;
	private DoubleLinkedListNode tail;
	private Integer size;

	/**
	 * This method is used for create Double Linked List with Start Node
	 * @param value
	 * @return
	 */
	public void createDoubleLinkedList(Integer nodeValue) {
		// create empty node object
		DoubleLinkedListNode node = new DoubleLinkedListNode();
		// initialize node
		node.setPrevious(null);
		node.setValue(nodeValue);
		node.setNext(null);
		// linked head and tail to node
		head = node;
		tail = node;
		// increase size
		++size;
	}

	/**
	 * This method is used for insert new node at any location
	 * @param head
	 * @param tail
	 * @param newNodeValue
	 * @param location
	 */
	public void insertNewNode(Integer newNodeValue, Integer location) {
		// create empty node object
		DoubleLinkedListNode node = new DoubleLinkedListNode();
		// initialize node
		node.setValue(newNodeValue);
		if (head == null) {
			log.info("Double Linked List does not Exists");
		} else if (location.equals(0)) {
			node.setNext(head);
			node.setPrevious(null);
			head.setPrevious(node);
			head = node;
			// increase size
			++size;
		} else if (location >= size - 1) {
			node.setNext(null);
			node.setPrevious(tail);
			tail.setNext(node);
			tail = node;
			
			// increase size
			++size;
		} else {
			DoubleLinkedListNode tempNode = head;
			for (int i = 0; i < location - 1; ++i) { // loop till location of Linked List
				tempNode = (DoubleLinkedListNode) tempNode.getNext();
			}
			node.setPrevious(tempNode);
			node.setNext(tempNode.getNext());
			tempNode.setNext(node);
			tempNode.getNext().getNext().setPrevious(node);
			// increase size
			++size;
		}

	}
	
	/**
	 * This method is used for access all node value from start node to end node
	 */
	public void traversalOfDoubleLinkedList() {
		if (head != null && tail != null) {
			DoubleLinkedListNode tempNode = head;
			for (int i = 0; i < size; i++) {
				log.info((i+1)+" Node value is "+tempNode.getValue());
				tempNode = (DoubleLinkedListNode) tempNode.getNext();
			}
		}else {
			log.info("Head ::"+head+" Tail ::"+tail);
		}
		
	}
	
	/**
	 * This method is used for access all node value from end node to start node
	 */
	public void reverseTraversalOfDoubleLinkedList() {
		if (head != null && tail != null) {
			DoubleLinkedListNode tempNode = tail;
			for (int i = size-1 ; i >= 0; i--) {
				log.info((i+1)+" Node value is "+tempNode.getValue());
				tempNode = (DoubleLinkedListNode) tempNode.getPrevious();
			}
		}else {
			log.info("Head ::"+head+" Tail ::"+tail);
		}
		
	}
	
	/**
	 * This node is used for search node  in DLL
	 * @param searchNodeValue
	 * @return
	 */
	public Integer searchNode(Integer searchNodeValue) {
		DoubleLinkedListNode tempNode = head;
		for (int i = 0; i < size; i++) {
			Integer nodeValue = (Integer) tempNode.getValue();
			if(nodeValue.equals(searchNodeValue)) {
				return i+1;
			}
			tempNode = (DoubleLinkedListNode) tempNode.getNext();
		}
		return -1;
	}
	
	/**
	 * This node is used for delete specific node in DLL
	 * @param location
	 */
	public void deleteNode(Integer location) {
		if (location> size-1) {
			log.info("Enter location node does not exist in this Double Linked List");
		} else if(location.equals(0)) {
			head = (DoubleLinkedListNode) head.getNext();
			head.setPrevious(null);
			if(size.equals(1)) {
				head = null;	
				tail = null;
			}
			// decrease size(number of node)
			--size;
			log.info("Delete Node is Done!!");
		}else if (location >= size-1) {
			DoubleLinkedListNode tempNode = head;
			for (int i = 0; i < location-1; i++) {
				tempNode = (DoubleLinkedListNode) tempNode.getNext();
			}
			tempNode.getNext().setPrevious(null);
			tempNode.setNext(null);
			tail = tempNode;
			// decrease size(number of node)
			--size;
			log.info("Delete Node is Done!!");
		}else {
			DoubleLinkedListNode tempNode = head;
			for (int i = 0; i < location - 1; i++) { // loop till  previous location node of SLL
				tempNode = (DoubleLinkedListNode) head.getNext();
			}
			// get location node/ deletable node
			DoubleLinkedListNode deletableNode = (DoubleLinkedListNode) tempNode.getNext();
			// get next node reference of deletable node
			DoubleLinkedListNode nextLocationNode = (DoubleLinkedListNode) deletableNode.getNext();
			// change tempNode reference to nextNode reference and change next node previous to tempNode
			tempNode.setNext(nextLocationNode);
			nextLocationNode.setPrevious(tempNode);
			// decrease size(number of node)
			--size;
			log.info("Delete Node is Done!!");
		}
		
	}
	
	public void deleteEntireSingleLinkedList() {
		// nullify all node previous reference
		DoubleLinkedListNode tempNode = head;
		for (int i = 0; i < size; i++) {
			head.setPrevious(null);
			tempNode = tempNode.getNext();
		}
		// nullify head and tail
		head = null;
		tail = null;
		log.info("Delete Entier DLL is Done!!!");
	}

}
