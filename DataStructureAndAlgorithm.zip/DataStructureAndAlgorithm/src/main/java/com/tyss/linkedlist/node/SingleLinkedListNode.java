package com.tyss.linkedlist.node;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SingleLinkedListNode {
	private Object value;
	private SingleLinkedListNode next;

	@Override
	public String toString() {
		return "value =" + value;
	}
}
