package com.tyss.linkedlist.test;

import java.util.Scanner;

import com.tyss.linkedlist.CircularSingleLinkedList;
import com.tyss.linkedlist.DoubleLinkedList;
import com.tyss.linkedlist.node.DoubleLinkedListNode;
import com.tyss.linkedlist.node.SingleLinkedListNode;

import lombok.extern.java.Log;

@Log
public class DoubleLinkedListTest {

	public static void main(String[] args) {
		// create Scanner class object
		Scanner sc = new Scanner(System.in);
		// take first and second node value from keyboard
		log.info("Enter first node value ::");
		Integer firstNodeValue = sc.nextInt();

		// create CircularLinkedList object
		DoubleLinkedList dll = new DoubleLinkedList();
		// initialize default value of SingleLinkedList fields
		dll.setSize(0);
		dll.setHead(null);
		dll.setTail(null);

		// invoke createDoubleLinkedList(-) to create DLL with start node
		dll.createDoubleLinkedList(firstNodeValue);
		log.info("First node Value is " + dll.getHead().getValue());
		log.info("First node reference is " + dll.getHead().getNext());
		log.info("Circular Single Linked List Creation is Done!!!!");

		// insert new node at start of SLL
		log.info("Enter new node value for inserting new node at start of CSLL ::");
		Integer newNodeValue = sc.nextInt();
		log.info("Enter start location ::");
		Integer location = sc.nextInt();

		// invoke insertNewNode(-,-,-,-,-) method to insert new node at start of DLL
		dll.insertNewNode(newNodeValue, location);
		// print all node value
		DoubleLinkedListNode tempNode = dll.getHead();
		for (int i = 0; i < dll.getSize(); i++) {
			log.info((i + 1) + " node value is " + tempNode.getValue());
			tempNode = (DoubleLinkedListNode) tempNode.getNext();
		}

		// insert new node at end of DLL
		log.info("Enter new node value for inserting new node at end of CSLL ::");
		Integer newNodeValue2 = sc.nextInt();
		log.info("Enter end location ::");
		Integer location2 = sc.nextInt();

		// invoke insertNewNode(-,-,-,-,-) method to insert new node at end of DLL
		dll.insertNewNode(newNodeValue2, location2);
		// print all node value
		DoubleLinkedListNode tempNode2 = dll.getHead();
		for (int i = 0; i < dll.getSize(); i++) {
			log.info((i + 1) + " node value is " + tempNode2.getValue());
			tempNode2 = (DoubleLinkedListNode) tempNode2.getNext();
		}

		// insert new node at any specific location of DLL
		log.info("Enter new node value for inserting new node at any specific location of SLL ::");
		Integer newNodeValue3 = sc.nextInt();
		log.info("Enter any specific location ::");
		Integer location3 = sc.nextInt();

		// invoke insertNewNode(-,-,-,-,-) method to insert new node at any specific
		// location of DLL
		dll.insertNewNode(newNodeValue3, location3);
		// print all node value
		DoubleLinkedListNode tempNode3 = dll.getHead();
		for (int i = 0; i < dll.getSize(); i++) {
			log.info((i + 1) + " node value is " + tempNode3.getValue());
			tempNode3 = (DoubleLinkedListNode) tempNode3.getNext();
		}
		log.info("Insertion is Done!!!");
		log.info("Last node next value is "+dll.getTail().getNext());

		// Traversal Circular Single Linked List for print all node value
		dll.traversalOfDoubleLinkedList();
		
		// Reverse traversal of Double Linked List
		dll.reverseTraversalOfDoubleLinkedList();
		
		// search node in Circular Single Linked List
		log.info("Enter Search Node Value ::");
		Integer searchNodeValue = sc.nextInt();
		// invoke searchNode(-) method
		Integer searchNodeLocation = dll.searchNode(searchNodeValue);
		if (searchNodeLocation.equals(-1)) {
			log.info("Search Node is Not found in the given Circular Single Linked List");
		} else {
			log.info("Search Node value found in Node-" + searchNodeLocation);
		}

		// delete start node in SLL
		log.info("Enter start location for delete ::");
		Integer startNodeLocation = sc.nextInt();
		// invoke searchNode(-) method
		dll.deleteNode(startNodeLocation);
		// print all node value after delete node
		dll.traversalOfDoubleLinkedList();

		// delete start node in SLL
		log.info("Enter end location for delete ::");
		Integer endNodeLocation = sc.nextInt();
		// invoke searchNode(-) method
		dll.deleteNode(endNodeLocation);
		// print all node value after delete node
		dll.traversalOfDoubleLinkedList();

		// delete specific node in SLL
		log.info("Enter specific location for delete ::");
		Integer specificNodeLocation = sc.nextInt();
		// invoke searchNode(-) method
		dll.deleteNode(specificNodeLocation);
		// print all node value after delete node
		dll.traversalOfDoubleLinkedList();

		// delete entire Circular SingleLinkedList
		dll.deleteEntireSingleLinkedList();
		// print all node value after delete node
		dll.traversalOfDoubleLinkedList();
	}
}
