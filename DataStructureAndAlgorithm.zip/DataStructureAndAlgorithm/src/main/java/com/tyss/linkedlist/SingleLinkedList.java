package com.tyss.linkedlist;

import com.tyss.linkedlist.node.SingleLinkedListNode;

import lombok.Data;
import lombok.extern.java.Log;

@Log
@Data
public class SingleLinkedList {

	private SingleLinkedListNode head;
	private SingleLinkedListNode tail;
	private Integer size;

	/**
	 * This method is used for create Single Linked List with Start Node
	 * 
	 * @param value
	 * @return
	 */
	public SingleLinkedListNode[] createSingleLinkedList(Integer value) {
		// create empty node object
		SingleLinkedListNode node = new SingleLinkedListNode();
		// initialize node
		node.setValue(value);
		node.setNext(null);
		// linked head and tail to node
		head = node;
		tail = node;
		// increase size of node
		++size;
		// return head and tail
		SingleLinkedListNode[] headAndTail = new SingleLinkedListNode[2];
		headAndTail[0] = head;
		headAndTail[1] = tail;
		return headAndTail;
	}

	/**
	 * This method is used for insert new node at any location
	 * 
	 * @param head
	 * @param tail
	 * @param newNodeValue
	 * @param location
	 */
	public void insertNewNode(Integer newNodeValue, Integer location) {
		// create empty node object
		SingleLinkedListNode node = new SingleLinkedListNode();
		// initialize node
		node.setValue(newNodeValue);
		node.setNext(null);
		if (head == null) {
			log.info("Single Linked List does not Exists");
		} else if (location.equals(0)) {
			node.setNext(head);
			tail = head;
			head = node;
			// increase size
			++size;
		} else if (location >= size - 1) {
			tail.setNext(node);
			tail = node;
			// increase size
			++size;
		} else {
			SingleLinkedListNode tempNode = head;
			for (int i = 0; i < location - 1; ++i) { // loop till location of Linked List
				tempNode = (SingleLinkedListNode) tempNode.getNext();
			}
			node.setNext(tempNode.getNext());
			tempNode.setNext(node);
			// increase size
			++size;
		}

	}

	/**
	 * This method is used for access all node value
	 */
	public void traversalOfSingleLinkedList() {
		if (head != null && tail != null) {
			SingleLinkedListNode tempNode = head;
			for (int i = 0; i < size; i++) {
				log.info((i + 1) + " Node value is " + tempNode.getValue());
				tempNode = (SingleLinkedListNode) tempNode.getNext();
			}
		} else {
			log.info("Head ::" + head + " Tail ::" + tail);
		}

	}

	/**
	 * This node is used for search node in SLL
	 * 
	 * @param searchNodeValue
	 * @return
	 */
	public Integer searchNode(Integer searchNodeValue) {
		SingleLinkedListNode tempNode = head;
		for (int i = 0; i < size; i++) {
			Integer nodeValue = (Integer) tempNode.getValue();
			if (nodeValue.equals(searchNodeValue)) {
				return i + 1;
			}
			tempNode = (SingleLinkedListNode) tempNode.getNext();
		}
		return -1;
	}

	/**
	 * This node is used for delete specific node in SLL
	 * 
	 * @param location
	 */
	public void deleteNode(Integer location) {
		if (location.equals(0)) {
			head = (SingleLinkedListNode) head.getNext();
			if (head == null) {
				tail = null;
			}
			// decrease size(number of node)
			--size;
			log.info("Delete Node is Done!!");
		} else if (location >= size - 1) {
			SingleLinkedListNode tempNode = head;
			for (int i = 0; i < location - 1; i++) {
				tempNode = (SingleLinkedListNode) tempNode.getNext();
			}
			tail = tempNode;
			tempNode.setNext(null);
			// decrease size(number of node)
			--size;
			log.info("Delete Node is Done!!");
		} else {
			SingleLinkedListNode tempNode = head;
			for (int i = 0; i < location - 1; i++) { // loop till previous location node of SLL
				tempNode = (SingleLinkedListNode) head.getNext();
			}
			// get location node/ deletable node
			SingleLinkedListNode deletableNode = (SingleLinkedListNode) tempNode.getNext();
			// get next node reference of deletable node
			SingleLinkedListNode nextLocationNode = (SingleLinkedListNode) deletableNode.getNext();
			// change tempNode reference to nextNode reference
			tempNode.setNext(nextLocationNode);
			// decrease size(number of node)
			--size;
			log.info("Delete Node is Done!!");
		}

	}

	public void deleteEntireSingleLinkedList() {
		// nullify head and tail
		head = null;
		tail = null;
		log.info("Delete Entier SLL is Done!!!");
	}

}
