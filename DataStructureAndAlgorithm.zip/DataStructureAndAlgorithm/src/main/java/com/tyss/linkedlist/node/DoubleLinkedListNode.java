package com.tyss.linkedlist.node;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DoubleLinkedListNode {
	private DoubleLinkedListNode previous;
	private Object value;
	private DoubleLinkedListNode next;

	@Override
	public String toString() {
		return "value =" + value;
	}
}
