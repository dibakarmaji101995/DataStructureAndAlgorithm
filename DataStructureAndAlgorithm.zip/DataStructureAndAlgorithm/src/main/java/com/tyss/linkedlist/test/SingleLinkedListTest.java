package com.tyss.linkedlist.test;

import java.util.Scanner;

import com.tyss.linkedlist.SingleLinkedList;
import com.tyss.linkedlist.node.SingleLinkedListNode;

import lombok.extern.java.Log;

@Log
public class SingleLinkedListTest {

	public static void main(String[] args) {
		// create Scanner class object
		Scanner sc = new Scanner(System.in);
		// take first node value from keyboard
		log.info("Enter first node value ::");
		Integer firstNodeValue = sc.nextInt();

		// create SingleLinkedList object
		SingleLinkedList sll = new SingleLinkedList();
		// initialize default value of SingleLinkedList fields
		sll.setSize(0);
		sll.setHead(null);
		sll.setTail(null);

		// create Single Linked List
		sll.createSingleLinkedList(firstNodeValue);
		log.info("First node Value is " + sll.getHead().getValue());
		log.info("First node reference is " + sll.getHead().getNext());
		log.info("Single Linked List Creation is Done!!!!");

		// insert new node at start of SLL
		log.info("Enter new node value for inserting new node at start of SLL ::");
		Integer newNodeValue = sc.nextInt();
		log.info("Enter start location ::");
		Integer location = sc.nextInt();

		// invoke insertNewNode(-,-,-,-,-) method to insert new node at start of SLL
		sll.insertNewNode(newNodeValue, location);
		// print all node value
		SingleLinkedListNode tempNode = sll.getHead();
		for (int i = 0; i < sll.getSize(); i++) {
			log.info((i + 1) + " node value is " + tempNode.getValue());
			tempNode = (SingleLinkedListNode) tempNode.getNext();
		}

		// insert new node at end of SLL
		log.info("Enter new node value for inserting new node at end of SLL ::");
		Integer newNodeValue2 = sc.nextInt();
		log.info("Enter end location ::");
		Integer location2 = sc.nextInt();

		// invoke insertNewNode(-,-,-,-,-) method to insert new node at end of SLL
		sll.insertNewNode(newNodeValue2, location2);
		// print all node value
		SingleLinkedListNode tempNode2 = sll.getHead();
		for (int i = 0; i < sll.getSize(); i++) {
			log.info((i + 1) + " node value is " + tempNode2.getValue());
			tempNode2 = (SingleLinkedListNode) tempNode2.getNext();
		}

		// insert new node at any specific location of SLL
		log.info("Enter new node value for inserting new node at any specific location of SLL ::");
		Integer newNodeValue3 = sc.nextInt();
		log.info("Enter any specific location ::");
		Integer location3 = sc.nextInt();

		// invoke insertNewNode(-,-,-,-,-) method to insert new node at any specific
		// location of SLL
		sll.insertNewNode(newNodeValue3, location3);
		// print all node value
		SingleLinkedListNode tempNode3 = sll.getHead();
		for (int i = 0; i < sll.getSize(); i++) {
			log.info((i + 1) + " node value is " + tempNode3.getValue());
			tempNode3 = (SingleLinkedListNode) tempNode3.getNext();
		}
		log.info("Insertion is Done!!!");
		// Traversal Single Linked List for print all node value
		sll.traversalOfSingleLinkedList();

		// search node in Single Linked List
		log.info("Enter Search Node Value ::");
		Integer searchNodeValue = sc.nextInt();
		// invoke searchNode(-) method
		Integer searchNodeLocation = sll.searchNode(searchNodeValue);
		if (searchNodeLocation.equals(-1)) {
			log.info("Search Node is Not found in the given Single Linked List");
		} else {
			log.info("Search Node value found in Node-" + searchNodeLocation);
		}

		// delete specific node in SLL
		log.info("Enter Node location for delete ::");
		Integer deleteNodeLocation = sc.nextInt();
		// invoke searchNode(-) method
		sll.deleteNode(deleteNodeLocation);
		// print all node value after delete node
		sll.traversalOfSingleLinkedList();

		// delete entire SingleLinkedList
		sll.deleteEntireSingleLinkedList();
		// print all node value after delete node
		sll.traversalOfSingleLinkedList();
	}
}
