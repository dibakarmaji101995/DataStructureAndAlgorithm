package com.tyss;

import lombok.Data;

@Data
public class Demo {
	public int test() {
		try {
			return 1;
		} catch (Exception e) {
			// TODO: handle exception
			return 2;
		} finally {
			return 3;
		}
	}

	public static void main(String[] args) throws InterruptedException {
         Demo d = new Demo();
         System.out.println(d.test());
	}
}
