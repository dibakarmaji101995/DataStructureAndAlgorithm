package com.tyss.patternprint;

import java.util.Scanner;

import lombok.extern.java.Log;

@Log
public class TrianglePrintByStar3 {
	public static void main(String[] args) {
		//create Scanner class object
    	 Scanner sc = new Scanner(System.in);
    	 // get number of rows of triangle
         log.info("Enter Number of Rows ::");	 
    	 Integer numRow = sc.nextInt();
    	 //  get number of columns of triangle
    	 log.info("Enter Number of Columns ::");
    	 Integer numColumns = sc.nextInt();
    	 //print the triangle pattern
    	 log.info("The Triangle Pattern is ::");
    	 Integer k = 3;
    	 for(int i = 1; i<= numRow; ++i) {
    		 for(int j = 1; j <= numColumns; ++j) {
    			 if(j >= numRow-k && j <= numRow+k) {
    				 System.out.print("*");
    			 }else {
    				 System.out.print(" ");
    			 }
    		 }
    		 System.out.println();
    		 --k;
    	 }
	}
}
