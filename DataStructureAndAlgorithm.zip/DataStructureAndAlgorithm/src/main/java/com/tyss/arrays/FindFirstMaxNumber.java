package com.tyss.arrays;

import lombok.extern.java.Log;

@Log
public class FindFirstMaxNumber {
	public static void main(String[] args) {
		// Number array
		Integer[] numberArray = new Integer[] { 10,100,200, 20, 30, 40, 50, 60 };
		// size of array
		Integer length = numberArray.length;
		// take first index as first highest number
		Integer firstHighestNumber = numberArray[0];
		// find out first highest number from array of elements
		for (int i = 1; i < length; ++i) {
			if (numberArray[i] > firstHighestNumber) {
				firstHighestNumber = numberArray[i];
			}
		}
		log.info("First Highest Number ::" + firstHighestNumber);
		
		// find second highest number from array of number elements
		Integer secondHighestNumber = numberArray[0];
		for(int i = 1 ; i < length; ++i) {
			if(numberArray[i] > secondHighestNumber  && numberArray[i] < firstHighestNumber) {
				secondHighestNumber = numberArray[i];
			}
		}
		log.info(" Second Highest Number ::"+secondHighestNumber);
	}

}
