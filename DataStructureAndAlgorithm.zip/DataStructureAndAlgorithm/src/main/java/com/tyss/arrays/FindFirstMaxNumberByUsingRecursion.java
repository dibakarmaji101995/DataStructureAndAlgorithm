package com.tyss.arrays;

import lombok.extern.java.Log;

@Log
public class FindFirstMaxNumberByUsingRecursion {
	public static void main(String[] args) {
		// Number array
		Integer[] numberArray = new Integer[] { 10, 100, 200, 20, 30, 40, 50, 60 };
		// get length of array
		Integer length = numberArray.length - 1;
		// take first first highest number as minimum value of Integer
		Integer firstHighestNumber = Integer.MIN_VALUE;
		// find highest number by using recursive method
		Integer highestNumber = findHighestNumber(numberArray, length, firstHighestNumber);
		// print/display highest number
		log.info("Highest Number is :: " + highestNumber);

	}

	public static Integer findHighestNumber(Integer[] numberArray, Integer length, Integer firstHighestNumber) {
		// find out first highest number from array of elements

		// base condition
		if (length.equals(-1)) {
			return firstHighestNumber;
		} else if (numberArray[length] > firstHighestNumber) {
			firstHighestNumber = numberArray[length];
		}
		return	findHighestNumber(numberArray, length - 1, firstHighestNumber);
	}

}
