package com.tyss.arrays;

import java.util.Arrays;
import java.util.Scanner;

import lombok.extern.java.Log;

@Log
public class AllOperationsOn1DArray {

	public static void main(String[] args) {
		// create Scanner class object
		Scanner sc = new Scanner(System.in);
		// take search element from keyboard
		log.info("Enter Insert Number ::");
		Integer insertElement = sc.nextInt();
		// create Integer array with size 10
		Integer[] numArray = new Integer[10];
		// initialize array with some elements
		numArray[0] = 10;
		numArray[1] = 20;

		// invoke insert(-,-,-) method to insert new element ( Insert Operation)
		insert(numArray, 2, insertElement);
		log.info("Display Array after insertion ::" + Arrays.asList(numArray).toString());

		// invoke traverse(-) method to dispaly each element of an array (Traverse Operation)
		traverse(numArray);
		
		// invoke accessIndex(-,-) method to get its index value/element
		log.info("Enter Index Number ::");
		Integer indexNumber = sc.nextInt();
		Integer element = accessIndex(numArray, indexNumber);
		if(element.equals(-1)) {
			log.info(indexNumber+" is gater than size of array");
		}else {
			log.info("The element in index "+indexNumber+" is "+element);
		}
		
		// invoke searchElement(-,-) method to search element in 1D array
		log.info("Enter Search Element ::");
		Integer searchElement = sc.nextInt();
		Integer searchElementIndex = searchElement(numArray, searchElement);
        if(searchElementIndex.equals(-1)) {
        	log.info(searchElement+ " not found in  the given 1D array");
        }else {
        	log.info(searchElement+" found in index "+searchElementIndex+" of the given 1D array");
        }
        
        // invoke deleteElement(-,-) method to delete given index element
        log.info("Enter index number for Delete element ::");
		Integer deleteElementIndexNumber = sc.nextInt();
        deleteElement(numArray, deleteElementIndexNumber);
        log.info("Dispaly Array after Delete element ::"+Arrays.asList(numArray).toString());
	}

	/**
	 * This method is used for insert element to a given array after last element
	 * 
	 * @param numArray
	 * @param location
	 */
	public static void insert(Integer[] numArray, Integer location, Integer newElement) {
		if (numArray[location] != null) {
			log.info("This location already has an element");
		} else {
			numArray[location] = newElement;
			log.info("Insert Is Done!!!");
		}
	}

	/**
	 * This method is used for Traversing a given 1D Array
	 * 
	 * @param numArray
	 */
	public static void traverse(Integer[] numArray) {
		for (int i = 0; i < numArray.length; i++) {
			if (numArray[i] != null) {
				log.info(i + " index element ::" + numArray[i]);
			}
		}
	}
	
	/**
	 * This method is used for access given index vale/element
	 * @param arr
	 * @param indexNumber
	 * @return
	 */
	public static Integer accessIndex(Integer[] arr, Integer indexNumber) {
		if(indexNumber > arr.length) {
			return -1;
		}else {
			return arr[indexNumber];
		}
	}
	
	/**
	 * This method is used for search element in 1D array
	 * @param arr
	 * @param searchElement
	 * @return
	 */
	public static Integer searchElement(Integer[] arr, Integer searchElement) {
		for (int i = 0; i < arr.length; i++) {
			if(arr[i].equals(searchElement)) {
				return i;
			}
		}
		return -1;
	}
	
	/**
	 * This method is used for delete element of given index of the given 1D array
	 * @param arr
	 * @param indexNumber
	 */
	public static void deleteElement(Integer[] arr, Integer indexNumber) {
		if(arr[indexNumber] != null) {
			arr[indexNumber] = null;
			log.info("Delete element is done");
		}else {
			log.info("Delete element is not possible because the given index dont have value/element");
		}
	}
}
