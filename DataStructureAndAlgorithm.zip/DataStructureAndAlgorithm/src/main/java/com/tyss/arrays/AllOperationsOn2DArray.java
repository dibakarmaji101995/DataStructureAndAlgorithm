package com.tyss.arrays;

import java.util.Arrays;
import java.util.Scanner;

import lombok.extern.java.Log;

@Log
public class AllOperationsOn2DArray {

	public static void main(String[] args) {
		// create Scanner class object
		Scanner sc = new Scanner(System.in);
		// take search element from keyboard
		log.info("Enter Insert Number ::");
		Integer insertElement = sc.nextInt();
		// create Integer array with size 10
		Integer[][] numArray = new Integer[5][3];
		// initialize array with some elements
		numArray[0][0] = 10;
		numArray[0][1] = 20;
		numArray[0][2] = 30;

		numArray[1][0] = 40;
		numArray[1][1] = 50;
		numArray[1][2] = 60;

		// invoke insert(-,-,-) method to insert new element ( Insert Operation)
		insert(numArray, 2, 0, insertElement);
		log.info("Display Array after insertion ::");
		Arrays.asList(numArray).stream().forEach(array -> System.out.println(Arrays.asList(array).toString()));
		Arrays.asList(numArray).stream().forEach(System.out::print);

		// invoke traverse(-) method to dispaly each element of an array (Traverse
		// Operation)
		traverse(numArray);

		// invoke accessIndex(-,-) method to get its index value/element
		log.info("Enter row and column for access its element ::");
		Integer row = sc.nextInt();
		Integer column = sc.nextInt();
		Integer element = accessIndex(numArray, row, column);
		if (element.equals(-1)) {
			log.info(row + " is gater than size of array");
		}else if (element.equals(-2)) {
			log.info(row + " is gater than size of array");
		} else {
			log.info("The element in row " + row+" and column "+column +" is " + element);
		}

		// invoke searchElement(-,-) method to search element in 1D array
		log.info("Enter Search Element ::");
		Integer searchElement = sc.nextInt();
		Integer[] searchElementIndex = searchElement(numArray, searchElement);
		if (searchElementIndex[0].equals(-1)) {
			log.info(searchElement + " not found in  the given 2D array");
		} else {
			log.info(searchElement + " found in row " + searchElementIndex[0]+" and column "+ searchElementIndex[1]+ " of the given 2D array");
		}

		// invoke deleteElement(-,-) method to delete given index element
		log.info("Enter row and column for delete ::");
		Integer deleteRow = sc.nextInt();
		Integer deleteColumn = sc.nextInt();
		deleteElement(numArray, deleteRow, deleteColumn);
		log.info("Dispaly Array after Delete element ::");
        Arrays.asList(numArray).stream().forEach(array -> { System.out.println(Arrays.asList(array).toString());});
	}

	/**
	 * This method is used for insert element to a given array after last element
	 * 
	 * @param numArray
	 * @param location
	 */
	public static void insert(Integer[][] numArray, Integer row, Integer column, Integer newElement) {
		if (numArray[row][column] != null) {
			log.info("This location already has an element");
		} else {
			numArray[row][column] = newElement;
			log.info("Insert Is Done!!!");
		}
	}

	/**
	 * This method is used for Traversing a given 1D Array
	 * 
	 * @param numArray
	 */
	public static void traverse(Integer[][] numArray) {
		for (int i = 0; i < numArray.length; i++) {
			for (int j = 0; j < numArray[0].length; j++) {
				if (numArray[i][j] != null) {
					log.info("[" + i + "]" + "[" + j + "]" + " index element ::" + numArray[i][j]);
				}
			}
		}
	}

	/**
	 * This method is used for access given index vale/element
	 * 
	 * @param arr
	 * @param indexNumber
	 * @return
	 */
	public static Integer accessIndex(Integer[][] arr, Integer row, Integer column) {
		if (row > arr.length ) {
			return -1;
		}else if(column > arr[0].length) {
			return -2;
		} else {
			return arr[row][column];
		}
	}

	/**
	 * This method is used for search element in 1D array
	 * 
	 * @param arr
	 * @param searchElement
	 * @return
	 */
	public static Integer[] searchElement(Integer[] [] arr, Integer searchElement) {
		Integer[] index = new Integer[2];
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[0].length; j++) {
				if (arr[i][j].equals(searchElement)) {
					index[0] = i;
					index[1] = j;
					return index;
				}	
			}
		}
		index[0] = -1;
		return index;
	}

	/**
	 * This method is used for delete element of given index of the given 1D array
	 * 
	 * @param arr
	 * @param indexNumber
	 */
	public static void deleteElement(Integer[] [] arr, Integer row, Integer column) {
		if (arr[row] [column] != null) {
			arr[row] [column] = null;
			log.info("Delete element is done");
		} else {
			log.info("Delete element is not possible because the given index dont have value/element");
		}
	}
}
