package com.tyss.stream.api;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class StreamOpertionsOnListOfEmployeeObject {

	public StreamOpertionsOnListOfEmployeeObject() {
	}

	public static void main(String[] args) {
		StreamOpertionsOnListOfEmployeeObject sooloeo = new StreamOpertionsOnListOfEmployeeObject();
		List<Employee> empList = sooloeo.getEmployeeList();
		// get male and female employee count from empList
		System.out.println(sooloeo.getMaleAndFemaleCount(empList));
		// get all dept from employee list
		System.out.println(sooloeo.getAllDepertmentsFromEmpList(empList));
		// get average age of male and female employees
		System.out.println(sooloeo.getAverageAgeOfMaleAndFemaleEmployee(empList));
		// get highest paid emp details from emp list
		System.out.println(sooloeo.getHighestPaidEmployeeDetails(empList));
		// get all employees name who join after 2015
		System.out.println(sooloeo.getAllEmployeeNameWhoJoinAfter2015(empList));
		// get each dept employee count
		System.out.println(sooloeo.getEachDeptEmployeeCount(empList));
		// get average salary of each dept
		System.out.println(sooloeo.getAverageSalaryOfEachDept(empList));
		// get youngest employee details from product development dept
		System.out.println("Youngest Employee from product development dept ::"
				+ sooloeo.getYoungestEmployeeDetailsFromProductDevelopmentDepartment(empList));
		// get most work experience employee details from emp list
		System.out.println("Most Experience Employee ::" + sooloeo.getMostWorkingExperienceEmployeeDetails(empList));
		// get count of male and female employees from sales and markating dept
        System.out.println("Sales and Marketing Dept Male and Female Employees Count ::"+sooloeo.getCountOfMaleAndFemaleEmployeesFromSalesAndMarketingDept(empList));
        // get average salary of male and female employees
        System.out.println("Average Salary of Male and Female Employees ::"+sooloeo.getAverageSalaryOfMaleAndFemaleEmployee(empList));
        // get all employee name list from each dept
        System.out.println(" Get All Employee Name List from Each Dept ::"+sooloeo.getAllEmployeeNameListFromEachDept(empList));
        // get average and total salary of whole organization
        System.out.println("Average and Total Salary of Whole Organization is ::"+sooloeo.getAverageAndTotalSalaryOfWholeOrganization(empList));
        // get all young employees whose age below or equal to 25
        System.out.println("Young Employees Whose Age Below or Equal to 25 ::"+sooloeo.getEmployeesWhoAgeYoungerOrEqualTo25(empList));
        // get oldest employee
        Employee oldestEmployee = sooloeo.getOldestEmployeeDetails(empList);
        System.out.println("Oldest Employee in the Organization ::");
        System.out.println("Oldest Employee Name ::"+oldestEmployee.getName());
        System.out.println("Oldest Employee Age ::"+oldestEmployee.getAge());
        System.out.println("Oldest Employee Dept ::"+oldestEmployee.getDepartment());
	}
	
	public Employee getOldestEmployeeDetails(List<Employee> empList) {
		Optional<Employee> optionalEmployee = empList.stream().sorted(Comparator.comparingInt(Employee::getAge).reversed()).findFirst();
		return optionalEmployee.orElse(new Employee());
	}
	
	public List<Employee> getEmployeesWhoAgeYoungerOrEqualTo25(List<Employee> empList){
		return empList.stream().filter(emp -> emp.getAge()<= 25).collect(Collectors.toList());
	}
	
	public Map<String, Double> getAverageAndTotalSalaryOfWholeOrganization(List<Employee> empList) {
		Map<String, Double> averageAndTotalSalaryMap = new HashMap<>();
		Double averageSalary = empList.stream().collect(Collectors.averagingDouble(Employee::getSalary));
		Double totalSalary = empList.stream().collect(Collectors.summingDouble(Employee::getSalary));
		averageAndTotalSalaryMap.put("Average Salary", averageSalary);
		averageAndTotalSalaryMap.put("Total Salary", totalSalary);
		return averageAndTotalSalaryMap;
	}
	
	public Map<String, List<String>> getAllEmployeeNameListFromEachDept(List<Employee> empList) {
		return empList.stream().collect(Collectors.groupingBy(Employee::getDepartment, Collectors.mapping(Employee::getName, Collectors.toList())));
	}
	
	public Map<String, Double> getAverageSalaryOfMaleAndFemaleEmployee(List<Employee> empList) {
		return empList.stream()
				.collect(Collectors.groupingBy(Employee::getGender, Collectors.averagingDouble(Employee::getSalary)));
	}

	public Map<String, Long> getCountOfMaleAndFemaleEmployeesFromSalesAndMarketingDept(List<Employee> empList) {
		return empList.stream().filter(emp -> "Sales And Marketing".equals(emp.getDepartment()))
				.collect(Collectors.groupingBy(Employee::getGender, Collectors.counting()));
	}

	public Employee getMostWorkingExperienceEmployeeDetails(List<Employee> empList) {
		Optional<Employee> optionalEmployee = empList.stream()
				.sorted(Comparator.comparingInt(Employee::getYearOfJoining)).findFirst();
		return optionalEmployee.orElse(new Employee());
	}

	public Employee getYoungestEmployeeDetailsFromProductDevelopmentDepartment(List<Employee> empList) {
		Optional<Employee> optionalEmployee = empList.stream()
				.filter(emp -> "Product Development".equals(emp.getDepartment()))
				.sorted(Comparator.comparingInt(Employee::getAge)).findFirst();
		return optionalEmployee.orElse(new Employee());
	}

	public Map<String, Double> getAverageSalaryOfEachDept(List<Employee> empList) {
		return empList.stream().collect(
				Collectors.groupingBy(Employee::getDepartment, Collectors.averagingDouble(Employee::getSalary)));
	}

	public Map<String, Long> getEachDeptEmployeeCount(List<Employee> empList) {
		return empList.stream().collect(Collectors.groupingBy(Employee::getDepartment, Collectors.counting()));
	}

	public List<String> getAllEmployeeNameWhoJoinAfter2015(List<Employee> empList) {
		return empList.stream().filter(emp -> emp.getYearOfJoining() > 2015).map(Employee::getName)
				.collect(Collectors.toList());
	}

	public Employee getHighestPaidEmployeeDetails(List<Employee> empList) {
		Optional<Employee> optionalEmployee = empList.stream()
				.sorted(Comparator.comparingDouble(Employee::getSalary).reversed()).findFirst();
		return optionalEmployee.orElse(new Employee());
	}

	public Map<String, Double> getAverageAgeOfMaleAndFemaleEmployee(List<Employee> empList) {
		return empList.stream()
				.collect(Collectors.groupingBy(Employee::getGender, Collectors.averagingDouble(Employee::getAge)));
	}

	public List<String> getAllDepertmentsFromEmpList(List<Employee> empList) {
		return empList.stream().map(Employee::getDepartment).distinct().collect(Collectors.toList());
	}

	public Map<String, Long> getMaleAndFemaleCount(List<Employee> empList) {
		return empList.stream().collect(Collectors.groupingBy(Employee::getGender, Collectors.counting()));
	}

	public List<Employee> getEmployeeList() {
		List<Employee> employeeList = new ArrayList<Employee>();

		employeeList.add(new Employee(111, "Jiya Brein", 32, "Female", "HR", 2011, 25000.0));
		employeeList.add(new Employee(122, "Paul Niksui", 25, "Male", "Sales And Marketing", 2015, 13500.0));
		employeeList.add(new Employee(133, "Martin Theron", 29, "Male", "Infrastructure", 2012, 18000.0));
		employeeList.add(new Employee(144, "Murali Gowda", 28, "Male", "Product Development", 2014, 32500.0));
		employeeList.add(new Employee(155, "Nima Roy", 27, "Female", "HR", 2013, 22700.0));
		employeeList.add(new Employee(166, "Iqbal Hussain", 43, "Male", "Security And Transport", 2016, 10500.0));
		employeeList.add(new Employee(177, "Manu Sharma", 35, "Male", "Account And Finance", 2010, 27000.0));
		employeeList.add(new Employee(188, "Wang Liu", 31, "Male", "Product Development", 2015, 34500.0));
		employeeList.add(new Employee(199, "Amelia Zoe", 24, "Female", "Sales And Marketing", 2016, 11500.0));
		employeeList.add(new Employee(200, "Jaden Dough", 38, "Male", "Security And Transport", 2015, 11000.5));
		employeeList.add(new Employee(211, "Jasna Kaur", 27, "Female", "Infrastructure", 2014, 15700.0));
		employeeList.add(new Employee(222, "Nitin Joshi", 25, "Male", "Product Development", 2016, 28200.0));
		employeeList.add(new Employee(233, "Jyothi Reddy", 27, "Female", "Account And Finance", 2013, 21300.0));
		employeeList.add(new Employee(244, "Nicolus Den", 24, "Male", "Sales And Marketing", 2017, 10700.5));
		employeeList.add(new Employee(255, "Ali Baig", 23, "Male", "Infrastructure", 2018, 12700.0));
		employeeList.add(new Employee(266, "Sanvi Pandey", 26, "Female", "Product Development", 2015, 28900.0));
		employeeList.add(new Employee(277, "Anuj Chettiar", 31, "Male", "Product Development", 2012, 35700.0));

		// return employeeList
		return employeeList;
	}
}
