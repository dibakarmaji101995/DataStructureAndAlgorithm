package com.tyss.stream.api;

import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Collectors;


public class StreamOperations {
	
	private final String name;
	{
		name = "Dibakar";
	}

	public static void main(String[] args) {
		StreamOperations streamOperation = new StreamOperations();
		System.out.println(streamOperation.name);
		// create List object
		List<Integer> intList = Arrays.asList(10, 90, 50, 40, 30, 60, 20, 100, 100, 200, 300, 400, 500, 600, 700, 800, 900,
				1000);

		// perform stream map operation (Intermediate operation)

		// Ex.1 ::
		List<Integer> functionalList = intList.stream().map(integer -> integer * 2).collect(Collectors.toList());
		// display all elements of list after apply function
		System.out.println("After applying function on each elements ::"+functionalList);

		// Ex.2 :: convert list of Integer to List of String (lambda expression)
		List<String> functionalList2 = intList.stream().map(integer -> String.valueOf(integer))
				.collect(Collectors.toList());
		// display all elements of list after apply function
		System.out.println("Convert list of Integer to List of String (lambda expression)::" + functionalList2);
        System.out.println("Check List type ::"+functionalList2.get(0).getClass().getName());
        
		// Ex.3 :: convert list of Integer to List of String (eleminate lambda expression by method reference)
		List<String> functionalList3 = intList.stream().map(String :: valueOf).collect(Collectors.toList());
		// display all elements of list after apply function
		System.out
				.println("Convert list of Integer to List of String (eliminate lambda expression by method reference)::"
						+ functionalList3);
		System.out.println("Check List type ::"+functionalList3.get(0).getClass().getName());
		
		// perform stream filter operation (Intermediate operation)
		
		// Ex.1 :: filter numbers from given range (By using Lambda expression)
		List<Integer> filterList = intList.stream().filter(integer -> integer >= 50 && integer <= 500).collect(Collectors.toList());
		// display filter elements
		System.out.println("Filter elements ::"+filterList);
		
		// perform stream flatMap operation (Intermediate operation)
		
		// Ex.1 :: filter numbers from given range (By using Lambda expression)
		
		List<List<Integer>> listOfIntegerList = Arrays.asList(Arrays.asList(10,30,20),Arrays.asList(40,70,50), Arrays.asList(90,100,200));
		System.out.println("List of List of Integer ::");
		listOfIntegerList.stream().forEach(System.out :: println);
		// convert list of list of integer into list of integer by using stream flatMap operation
		//List<Integer> integerList = listOfIntegerList.stream().flatMap(list -> list.stream()).collect(Collectors.toList());
		List<Integer> integerList = listOfIntegerList.stream().flatMap(Collection :: stream).collect(Collectors.toList());
		// display integerList
		System.out.println("List of Integer ::");
		integerList.stream().forEach(System.out :: println);
		List<Integer> filterList2 = integerList.stream().filter(integer -> integer >= 50 && integer <= 500)
				.collect(Collectors.toList());
		// display filter elements
		System.out.println("Filter elements ::" + filterList2);
		
		
		// perform stream sorted operation (Intermediate operation)
		
		// ascending order sort
		List<Integer> ascendingOrderSortedList = intList.stream().sorted().collect(Collectors.toList());
		System.out.println("Ascending order sorted List ::"+ascendingOrderSortedList);
		// descending order sorting
		List<Integer> sortedList = intList.stream().sorted(Comparator.comparingInt(integer -> Integer.valueOf(""+integer)).reversed()).collect(Collectors.toList());
		System.out.println("Descending order Sorted List::"+sortedList);
		
		// perform stream min operation (Terminal operation)
		
		Optional<Integer> optionalInteger = intList.stream().min(Comparator.comparingInt(integer -> Integer.valueOf(""+integer)));
		if(optionalInteger.isPresent()) {
			System.out.println("Min Element ::"+optionalInteger.get());	
		}else {
			System.out.println("No Such Element found in Optional Object ::"+Optional.empty());
		}
		
		// perform stream max operation (Terminal operation)

		Optional<Integer> optionalInteger2 = intList.stream()
				.max(Comparator.comparingInt(integer -> Integer.valueOf("" + integer)));
		if (optionalInteger.isPresent()) {
			System.out.println("Max Element ::"+optionalInteger2.get());
		} else {
			System.out.println("No Such Element found in Optional Object ::" + Optional.empty());
		}
		
		// perform stream count operation (Terminal operation)
		
		Long numberOfElementsOfStream = intList.stream().count();
		System.out.println("Number of Elements of Stream ::"+numberOfElementsOfStream);
		
		// perform stream distinct operation (Terminal operation)
		// get non-duplicate elements list
		List<Integer> distinctList = intList.stream().distinct().collect(Collectors.toList());
		System.out.println(distinctList);
		
		Set<String> stringSet = new HashSet<>();
		stringSet.contains("");
		Integer num = Math.abs(-34);
		System.out.println(num);
		System.out.println(-9<-8);
	}
}
