package com.tyss.Java_8_Features;

@FunctionalInterface
public interface MyFunctionalInterface {
     public static final Integer FIRST_INT = 10;
     public static final Integer SECOND_INT = 10;
     public static final Integer THIRD_INT = 10;
     
     public abstract void m1();
     
     public static void add() {}
     public static void add2() {}
     public static void add3() {}
     public static void add4() {}
     
     public default void sub() {}
     public default void sub2() {}
     public default void sub3() {}
     
     public abstract String toString();
     
     public abstract boolean equals(Object obj);
     
  //   public default int hashCode() {
  //  	 return 10;
   //  }
}
