package com.tyss.collections.classes;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class SetImplementedClassesOperationsTest {

	public static void main(String[] args) {
		Set<Object> hs = new HashSet<>();
		hs.add("f");
		hs.add("b");
		hs.add("r");
		System.out.println(hs);
		System.out.println(hs.iterator().next());
		System.out.println(hs.iterator().next().hashCode());
		
	}

}
