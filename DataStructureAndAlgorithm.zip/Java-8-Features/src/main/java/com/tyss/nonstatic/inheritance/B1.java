package com.tyss.nonstatic.inheritance;

public class B1 extends A1 {
	int y = m2();

	public int m2() {
		System.out.println("B NSV");
		return 20;
	}

	{
		System.out.println("B NSB");
	}

	public B1() {
		System.out.println("B Constructor");
	}
}
