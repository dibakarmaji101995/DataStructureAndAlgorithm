package com.tyss.nonstatic.inheritance;

public class A1 {
	int x = m1();

	public int m1() {
		System.out.println(" A NSV");
		return 10;
	}
	{
		System.out.println("A NSB");
	}
	
	public A1()
	{
		System.out.println("A Constructor");
	}
	
	

}
