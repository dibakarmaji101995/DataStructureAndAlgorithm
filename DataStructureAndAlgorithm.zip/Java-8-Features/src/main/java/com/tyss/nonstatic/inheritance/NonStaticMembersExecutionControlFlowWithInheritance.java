package com.tyss.nonstatic.inheritance;

public class NonStaticMembersExecutionControlFlowWithInheritance {

	public static void main(String[] args) {
		System.out.println("From main method");

		// create B1 subclass object
		B1 b = new B1();
		// Acess super class and subclass non static members
		System.out.println("X : " + b.x);
		System.out.println("Y : " + b.y);

	}

}
