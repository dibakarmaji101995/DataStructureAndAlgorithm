package com.tyss.stack.test;

import com.tyss.stack.ImplementStackByUsingQueue1;

import lombok.extern.java.Log;

@Log
public class ImplementStackByUsingQueue1Test {
    
	public static void main(String[] args) {
		// create empty stack
		ImplementStackByUsingQueue1 stack = new ImplementStackByUsingQueue1();
		
		// push data in stack
		stack.push(10);
		stack.push(40);
		stack.push(20);
		stack.push(30);
		
		log.info("Stack elemts after push data in Stack::"+stack.toString());
		
		// pop in stack
		log.info("Pop element in stack is "+stack.pop());
		log.info("After pop stack elements are "+stack.toString());
		// peek in stack
		log.info("Peek element in stack is "+stack.peek());
		
		// push new data
		stack.push(89);
		
		log.info("Peek data in stack is "+stack.peek());
		
	}
}
