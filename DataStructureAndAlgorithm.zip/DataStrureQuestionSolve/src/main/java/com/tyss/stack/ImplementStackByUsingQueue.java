package com.tyss.stack;

import java.util.LinkedList;
import java.util.Queue;

import lombok.Data;

@Data
public class ImplementStackByUsingQueue {
	private Queue<Integer> queue1;
	private Queue<Integer> queue2;

	public ImplementStackByUsingQueue() {
		queue1 = new LinkedList<Integer>();
		queue2 = new LinkedList<Integer>();
	}
	
	/**
	 * This method is used for insert element in stack
	 * @param insertValue
	 */
	public void push1(Integer insertValue) {
		// get size of queue
		Integer sizeOfQueue = queue1.size();
		//insert new element
		queue1.add(insertValue);
		for (int i = 0; i < sizeOfQueue; i++) {
			// swap previos elements of queue to last
			queue1.add(queue1.remove());
		}
	}
	
	/**
	 * This method is used to push new element to Stack
	 * @param insertValue
	 */
	public void push(Integer insertValue) {
		if (queue1.isEmpty()) {
			queue1.add(insertValue);
		}else {
			// copy queue1 elements to queue2
			while(queue1.size() !=0) {
				queue2.add(queue1.remove());
			}
			// add new element to queue1
			queue1.add(insertValue);
			// copy queue2 elements to queue1
			while (queue2.size() != 0) {
				queue1.add(queue2.remove());
			}
		}
	}
	
	/**
	 * This method is used for pop elements from stack
	 * @return
	 */
	public Integer pop() {
		Integer popElement = null;
		if (queue1 != null) {
		    popElement = queue1.remove();	
		}
		return popElement;
	}
	
	/**
	 * 
	 * @return
	 */
	public Integer peek() {
	    Integer peekElement = null;
		if (queue1 != null) {
			peekElement = queue1.peek();
		}
		return peekElement;
	}
}
