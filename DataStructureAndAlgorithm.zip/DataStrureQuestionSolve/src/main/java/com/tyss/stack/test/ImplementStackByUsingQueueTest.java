package com.tyss.stack.test;

import com.tyss.stack.ImplementStackByUsingQueue;

import lombok.extern.java.Log;

@Log
public class ImplementStackByUsingQueueTest {

	public static void main(String[] args) {
		// create empty stack
		ImplementStackByUsingQueue stack = new ImplementStackByUsingQueue();

		// push new elements
		/*
		 * stack.push(10); stack.push(20); stack.push(30); stack.push(40);
		 */
		stack.push1(10);
		stack.push1(20);
		stack.push1(30);
		stack.push1(40);

		log.info("Stack Elements after insert ::" + stack.getQueue1());

		// pop element from stack
		log.info("Pop element is " + stack.pop());
		log.info("After pop Stack elements are " + stack.getQueue1());

		// peek element from stack
		log.info("Peek element is " + stack.peek());
		log.info("After peek Stack elements are " + stack.getQueue1());
	}

}
