package com.tyss.stack;

import com.tyss.queue.SingleLinkedListNode;

import lombok.ToString;
import lombok.extern.java.Log;

@Log
@ToString
public class ImplementStackByUsingQueue1 {
	private LinkedListImplementationOfLinearQueue queue;

	public ImplementStackByUsingQueue1() {
		queue = LinkedListImplementationOfLinearQueue.createLinearQueue();
	}

	/**
	 * 
	 * @param insertValue
	 */
	public void push(Object insertValue) {
		if (queue == null) {
			log.info("Queue is not exists");
			return;
		}
		queue.enqueue(insertValue);
	}

	/**
	 * 
	 * @return
	 */
	public Object pop() {
		if (queue == null) {
			log.info("Queue does not exists");
			return null;
		}
		// get previousNode of lastNode of Queue
		SingleLinkedListNode lastNode = queue.getTail();
		SingleLinkedListNode tempNode = queue.getHead();
		for (int i = 0; i < queue.getSize() - 2; i++) {
			tempNode = tempNode.getNext();
		}
		// set tail to previod node of lastNode
		queue.setTail(tempNode);
		tempNode.setNext(null);
		// return lastNode value
		return lastNode.getValue();
	}

	/**
	 * 
	 * @return
	 */
	public Object peek() {
		if (queue == null) {
			log.info("Queue does not exists");
			return null;
		}
		return queue.getTail().getValue();
	}

}
