package com.tyss.string;

import java.util.Scanner;

import lombok.extern.java.Log;

@Log
public class CheckBracketsFormationIsBanlancedOrNot {

	public static void main(String[] args) {
		// create Scanner class object
		Scanner sc = new Scanner(System.in);
		// take backets formation from console
		log.info("Enter brackets ::");
		String bracketsString = sc.next();
		// convert string into char array
		char[] charArray = bracketsString.toCharArray();
		// checked backet formation is balanced or not
		Integer openBracketCount = 0;
		Integer closeBracketCount = 0;
		for (int i = 0; i < charArray.length; i++) {
			Integer asciCode = (int) charArray[i];
			if (asciCode.equals(40)) {
				++openBracketCount;
			} else if (asciCode.equals(41)) {
				++closeBracketCount;
			}
		}
		if (closeBracketCount.equals(openBracketCount)) {
			System.out.println("Balanced");
		} else {
			System.out.println("Not Balanced");
		}
		
		// get num of operation required to balance the brackets
		log.info("Min Number of Operstion Required To Balanced Brackets ::"+getMinOpertionsRequiredToMakeItBalanced(bracketsString));
	}

	public static Integer getMinOpertionsRequiredToMakeItBalanced(String bracketsString) {
		// convert string into char array
		char[] charArray = bracketsString.toCharArray();
		// count open and close bracket
		Integer openBracketCount = 0;
		Integer closeBracketCount = 0;
		for (int i = 0; i < charArray.length; i++) {
			Integer asciCode = (int) charArray[i];
			if (asciCode.equals(40)) {
				++openBracketCount;
			} else if (asciCode.equals(41)) {
				++closeBracketCount;
			}
		}
		// return no of insert opertion required
		return Math.abs(openBracketCount-closeBracketCount);
	}
}
