package com.tyss.string;

public class CapitalizeFirstLetterOfString {

	public static void main(String[] args) {
		String inputString = "dibakar";
		System.out.println(inputString.substring(0, 1).toUpperCase().concat(inputString.substring(1).toLowerCase()));
	}
}
