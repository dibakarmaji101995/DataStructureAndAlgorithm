package com.tyss.array.test;

import com.tyss.array.GetMinimizedSumOfAbsoluteDifferencesOfAllAdjecentElements;

import lombok.extern.java.Log;

@Log
public class GetMinimizedSumOfAbsoluteDifferencesOfAllAdjecentElementsTest {

	public static void main(String[] args) {
		// create integer array
		Integer[] integerArray = new Integer[] {5,1,4,4,3,3};
		// create GetMinimizedSumOfAbsoluteDifferencesOfAllAdjecentElements class object
		GetMinimizedSumOfAbsoluteDifferencesOfAllAdjecentElements getSum = new GetMinimizedSumOfAbsoluteDifferencesOfAllAdjecentElements();
		// get minimized sum 
		Integer minimizedSum = getSum.getMinimizedSumOfAbsoluteDifferencesOfAllAdjecentElements(integerArray);
		
		// print minimizedSum
		log.info("Minimized Sum :: "+minimizedSum);
	}
}
