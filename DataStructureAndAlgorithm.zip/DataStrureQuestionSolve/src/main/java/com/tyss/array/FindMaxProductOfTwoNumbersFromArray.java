package com.tyss.array;

import lombok.Data;
import lombok.extern.java.Log;

@Log
@Data
public class FindMaxProductOfTwoNumbersFromArray {
	private Integer[] numArray;

	public FindMaxProductOfTwoNumbersFromArray(Integer size) {
		numArray = new Integer[size];
	}
	
	/**
	 * This method is used for find max product of two numbers from array
	 * @return
	 */
	public Integer findMaxProductOfTwoNumbersFromArray() {
		// find first largest number from array
		Integer firstLargestNumber = numArray[0];
		for (int i = 1; i < numArray.length; i++) {
			if(numArray[i] > firstLargestNumber) {
				firstLargestNumber = numArray[i];
			}
		}
		log.info("FIrst Largest Number ::"+firstLargestNumber);
		// find second largest number from array
		Integer secondLargestNumber = numArray[0];
		for (int i = 1; i < numArray.length; i++) {
			if (numArray[i] > secondLargestNumber && numArray[i] < firstLargestNumber) {
				secondLargestNumber = numArray[i];
			}
		}
		log.info("Second Largest Number ::"+secondLargestNumber);
		
		// return product of fierst and second largest number i.e a max product
		return firstLargestNumber * secondLargestNumber;
	}
}
