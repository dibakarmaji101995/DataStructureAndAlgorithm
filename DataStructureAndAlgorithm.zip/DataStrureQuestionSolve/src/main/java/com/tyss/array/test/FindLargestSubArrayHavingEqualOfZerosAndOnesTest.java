package com.tyss.array.test;

import com.tyss.array.FindLargestSubArrayHavingEqualNumberOfZerosAndOnes;

import lombok.extern.java.Log;

@Log
public class FindLargestSubArrayHavingEqualOfZerosAndOnesTest {
	public static void main(String[] args) {
		// create FindLargestSubArrayHavingEqualOfZerosAndOnes class object
		FindLargestSubArrayHavingEqualNumberOfZerosAndOnes findLargestSubArrayHavingEqualOfZerosAndOnes = new FindLargestSubArrayHavingEqualNumberOfZerosAndOnes(
				9);
		// get array and initialize it
		Integer[] integerArray = findLargestSubArrayHavingEqualOfZerosAndOnes.getNumArray();
		integerArray[0] = 1;
		integerArray[1] = 0;
		integerArray[2] = 1;
		integerArray[3] = 1;
		integerArray[4] = 1;
		integerArray[5] = 0;
		integerArray[6] = 0;
		integerArray[7] = 0;
		integerArray[8] = 0;
		// get largest sub-array length have equal number of 0's and 1's
		Integer maxLength = findLargestSubArrayHavingEqualOfZerosAndOnes.getLargestSubArrayLength();
		if(maxLength.equals(0)) {
			log.info("Does not get any sub array that has equal number of 0's and 1's");
		}else {
			log.info("Largest Sub-Array Length is " + maxLength);
		}
	}
}
