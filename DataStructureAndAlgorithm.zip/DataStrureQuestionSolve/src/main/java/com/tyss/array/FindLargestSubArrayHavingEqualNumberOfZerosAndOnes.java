package com.tyss.array;

import java.util.HashMap;
import java.util.Map;

import lombok.Data;
import lombok.extern.java.Log;

@Log
@Data
public class FindLargestSubArrayHavingEqualNumberOfZerosAndOnes {
	private Integer[] numArray;

	public FindLargestSubArrayHavingEqualNumberOfZerosAndOnes(Integer size) {
		numArray = new Integer[size];
	}

	/**
	 * This method is used for get Largest sub array have equal numbers of 0's and 1's
	 * @return
	 */
	public Integer getLargestSubArrayLength() {
		Integer sum = 0;
		Integer maxLength = 0;
		Integer endIndex = -1;
		Boolean flag = true;
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		// create temp array
		Integer[] tempArray = new Integer[numArray.length];
		// replace 0 with -1 and 1 with 1
		for (int i = 0; i < tempArray.length; i++) {
			tempArray[i] = numArray[i].equals(0) ? -1 : 1;
		} // end of for loop

		// find largest sub-array having equals 0 and 1
		for (int i = 0; i < tempArray.length; i++) {
			// sum of each element
			sum += tempArray[i];
			// check sum is equals to 0 then initialize maxLength

			if (sum.equals(0) && flag) {
				flag = false;
				maxLength = i + 1;
				endIndex = i;
			}
			
			// store each element sum with index
			if (!map.containsKey(sum)) {
				map.put(sum, i);
			}

			// if sum=0 is already store in map and if again we get sum=0 and check its
			// length > maxLength then
			// we update maxLength otherwise store sum with index
			if (map.containsKey(sum)) {
				if (sum.equals(0) && maxLength < (i - map.get(sum))) {
					maxLength = i - map.get(sum);
					endIndex = i;
				}
			}
		} // end of for loop
		// get start index
		Integer startIndex = endIndex - maxLength + 1;
		// check if maxLength is not equal to 0 then print start and end index of Sub-Array
		if (!maxLength.equals(0)) {
			log.info("Largest sub-array start from " + startIndex + " to " + endIndex);
		}
		// return maxlength
		return maxLength;
	}
}
