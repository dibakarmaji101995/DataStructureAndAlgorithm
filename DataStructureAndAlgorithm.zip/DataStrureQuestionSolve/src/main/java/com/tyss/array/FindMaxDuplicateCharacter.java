package com.tyss.array;

import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.OptionalInt;
import java.util.stream.Collectors;

public class FindMaxDuplicateCharacter {

	public String getMaxDuplicateCharacter(String inputString) {
		// create Map object
		Map<String,Integer> chractersOccurrenceMap = new LinkedHashMap<>();
		// convert string to char array
		char[] charArray = inputString.toCharArray();
		// finding each character number of occurrence
		for (int i = 0; i < charArray.length; i++) {
			String character = String.valueOf(charArray[i]);
			if(chractersOccurrenceMap.containsKey(character)) {
				Integer value = chractersOccurrenceMap.get(character);
				chractersOccurrenceMap.put(character, ++value);
			}else {
				chractersOccurrenceMap.put(character, 1);
			}
		}
		// find max occurrence character
		Integer maxNum = 0;
		String maxOccurCharString = "";
		for (Entry<String, Integer> entry : chractersOccurrenceMap.entrySet()) {
			if (entry.getValue()>maxNum) {
				maxNum = entry.getValue();
				maxOccurCharString = entry.getKey();
			}
		}
	    return maxOccurCharString;
	}
}
