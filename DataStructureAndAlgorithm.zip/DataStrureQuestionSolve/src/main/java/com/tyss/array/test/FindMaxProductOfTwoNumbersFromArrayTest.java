package com.tyss.array.test;

import com.tyss.array.FindLargestSubArrayHavingEqualNumberOfZerosAndOnes;
import com.tyss.array.FindMaxProductOfTwoNumbersFromArray;

import lombok.extern.java.Log;

@Log
public class FindMaxProductOfTwoNumbersFromArrayTest {
      public static void main(String[] args) {
    	// create FindMaxProductOfTwoNumbersFromArray class object
    	  FindMaxProductOfTwoNumbersFromArray findMaxProductOfTwoNumbersFromArray = new FindMaxProductOfTwoNumbersFromArray(
  				9);
  		// get array and initialize it
  		Integer[] integerArray = findMaxProductOfTwoNumbersFromArray.getNumArray();
  		integerArray[0] = 10;
  		integerArray[1] = 30;
  		integerArray[2] = 40;
  		integerArray[3] = 50;
  		integerArray[4] = 60;
  		integerArray[5] = 70;
  		integerArray[6] = 80;
  		integerArray[7] = 90;
  		integerArray[8] = 20;
  		// get max product of two numbers from array
  		Integer product = findMaxProductOfTwoNumbersFromArray.findMaxProductOfTwoNumbersFromArray();
  		log.info("Max Product ::"+product);
	}
}
