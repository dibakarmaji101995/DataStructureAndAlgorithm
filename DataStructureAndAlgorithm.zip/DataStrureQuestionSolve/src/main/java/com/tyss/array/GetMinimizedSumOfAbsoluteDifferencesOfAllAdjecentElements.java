package com.tyss.array;

import java.util.Arrays;
import java.util.Collections;

public class GetMinimizedSumOfAbsoluteDifferencesOfAllAdjecentElements {

	public Integer getMinimizedSumOfAbsoluteDifferencesOfAllAdjecentElements(Integer[] integerArray) {
		// sort array in ascending order
		Arrays.sort(integerArray);
		// calculate sum of each adjacent elements
		Integer sum = 0;
		for (int i = 0; i < integerArray.length - 1; i++) {
			Integer diff = Math.abs(integerArray[i] - integerArray[i + 1]);
			sum += diff;
		}
		Collections.sort(Arrays.asList(integerArray), Collections.reverseOrder());
		// return sum
		return sum;
	}
}
