package com.tyss.array;

import lombok.extern.java.Log;

@Log
public class FindMaxDuplicateCharacterTest {

	public static void main(String[] args) {
		// get string
		String inputString = "babbabac";
		// create FindMaxDuplicateCharacter class object
		FindMaxDuplicateCharacter findMaxDuplicateCharacter = new FindMaxDuplicateCharacter();
		// get max duplicate character
		log.info("Max Duplicate Characters ::"+findMaxDuplicateCharacter.getMaxDuplicateCharacter(inputString));
	}
}
