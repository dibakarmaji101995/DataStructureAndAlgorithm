package com.tyss.queue;

import com.tyss.queue.SingleLinkedListNode;

import lombok.Data;
import lombok.extern.java.Log;

@Log
@Data
public class LinkedListImplementationOfStack {
	
	/**
	 * This field is used for store first node reference
	 */
	private SingleLinkedListNode head;
	
	/**
	 * This field is used for store last node reference
	 */
	private SingleLinkedListNode tail;
	
	private Integer size;
	
	/**
	 * This method is used for create empty array with given size
	 * @param size
	 */
	public void createStack() {
		// initialize head as null value
		head = null;
		tail = null;
		size = 0;
		// print success message
		log.info("Creation of Stack is Done!!!!!!!");
	}
	
	/**
	 * This method is used for insert new element in top of stack
	 * @param value
	 */
	public void push(Object nodeValue) {
		// create empty node
		SingleLinkedListNode node = new SingleLinkedListNode();
		// initialize node fields
		node.setValue(nodeValue);
		node.setNext(head);
		head = node;

		size++;
		if (size.equals(1)) {
			tail = node;
		}
		// print success message
		log.info(nodeValue + " push is Done!!!");

	}
	
	/**
	 * This method is used for remove and return element of top of stack
	 * @return
	 */
	public Object pop() {
		if(head == null) {
			// print error message
			log.info("Push operation can not perform because of Linked List does not exists");
			return 0;
		}else {
			// take node from top of stack
			SingleLinkedListNode topElement = head;
			// remove node of top of stack
			head = head.getNext();
            
			size--;
			// return node value of top of stack
			return topElement.getValue();
		}
	}
	
	/**
	 * This method is used for peek element of top of stack
	 * @return
	 */
	public Object peek() {
		if(head == null) {
			// print error message
			log.info("Push operation can not perform because of Linked List does not exists");
			return 0;
		}else {
			// return element of  top of stack
			return head.getValue();
		}
	}
	
	/**
	 * This method is used for check array is empty or not
	 * @return
	 */
	public Boolean isEmpty() {
		if(head == null) {
			// return true
			return true;
		}else {
			// return false
			return false;
		}
	}
	
	/**
	 * This method is used for delete stack
	 */
	public void deleteStack() {
		// nullify array
		head = null;
		// print success message
		log.info("Stack delete is Done!!!!!!!");
	}
	
	public void traversalOfLinkedList() {
		if (head == null) {
			log.info("Traversal  can not perform because of Linked List does not exists");
		}else {
			SingleLinkedListNode tempNode = head;
			for (int i = 0; i < size; i++) {
				log.info("node-"+(i+1)+" value is "+tempNode.getValue());
				tempNode = tempNode.getNext();
			}
		}
	}

}
