package com.tyss.queue.test;

import com.tyss.queue.ImplementQueueByUsingStack;

import lombok.ToString;
import lombok.extern.java.Log;

@Log
@ToString
public class ImplementQueueByUsingStackTest {

	public static void main(String[] args) {
		// create empty queue
		ImplementQueueByUsingStack queue = new ImplementQueueByUsingStack();

		// push data in stack
		queue.enqueue(10);
		queue.enqueue(40);
		queue.enqueue(20);
		queue.enqueue(30);

		log.info("Stack elemts after push data in Stack::" + queue.toString());

		// pop in stack
		log.info("Pop element in stack is " + queue.dequeue());
		log.info("After pop stack elements are " + queue.toString());
		// peek in stack
		log.info("Peek element in stack is " + queue.peek());

		// push new data
		queue.enqueue(89);
		log.info("After pop stack elements are " + queue.toString());
		
		// peek element in Queue
		log.info("Peek data in stack is " + queue.peek());

	}
}
