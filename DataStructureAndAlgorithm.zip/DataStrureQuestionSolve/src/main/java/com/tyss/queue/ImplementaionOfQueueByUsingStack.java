package com.tyss.queue;

import java.util.Stack;

import lombok.Data;

@Data
public class ImplementaionOfQueueByUsingStack {
	
	private Stack<Integer> stack;
	
	public ImplementaionOfQueueByUsingStack() {
		stack = new Stack<Integer>();
	}
	
	public void enqueue(Integer enqueueElement) {
		if (stack != null) {
			stack.add(enqueueElement);
		}
	}
	
	public Integer dequeue() {
		// get size of stack
		Integer size = stack.size();
		// get top of stack
		Integer dequeueElement = stack.get(0);
		// delete top of stack
		stack.remove(0);
		// return enqueue element
		return dequeueElement;
	}
  
}
