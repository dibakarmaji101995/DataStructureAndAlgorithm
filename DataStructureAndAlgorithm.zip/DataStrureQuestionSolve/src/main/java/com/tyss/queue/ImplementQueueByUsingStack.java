package com.tyss.queue;

import lombok.Data;
import lombok.extern.java.Log;

@Log
@Data
public class ImplementQueueByUsingStack {
     
	private LinkedListImplementationOfStack stack;
	
	public ImplementQueueByUsingStack() {
	     stack = new LinkedListImplementationOfStack();
	     stack.createStack();
	}
	
	/**
	 * This methos is used for enqueue new data in Queue
	 * @param insertValue
	 */
	public void enqueue(Object insertValue) {
		if (stack == null) {
			log.info("Stack does not exists");
			return;
		}
		stack.push(insertValue);
	}
	
	/**
	 * This method is used for dequeue new data in queue
	 * @return
	 */
	public Object dequeue() {
		if (stack == null) {
			log.info("Stack does not exists");
			return null;
		}
		// get lastNode of stack
		SingleLinkedListNode lastNode = stack.getTail();
		// get previousNode of lastNode of stack
		SingleLinkedListNode tempNode = stack.getHead();
		for (int i = 0; i < stack.getSize() - 2; i++) {
			tempNode = tempNode.getNext();
		}
		// delete lastNode of stack
	    stack.setTail(tempNode);
	    tempNode.setNext(null);
		// return deleteNode value
		return  lastNode.getValue();
	}
	
	/**
	 * This method is used for peek element in Queue
	 * @return
	 */
	public Object peek() {
		if (stack == null) {
			log.info("Stack does not exists");
			return null;
		}
		return stack.getTail().getValue();
	}
}
