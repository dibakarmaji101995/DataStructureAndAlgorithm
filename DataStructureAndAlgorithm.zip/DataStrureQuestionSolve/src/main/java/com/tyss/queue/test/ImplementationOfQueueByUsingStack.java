package com.tyss.queue.test;

import com.tyss.queue.ImplementaionOfQueueByUsingStack;

import lombok.extern.java.Log;

@Log
public class ImplementationOfQueueByUsingStack {
      
	public static void main(String[] args) {
		// create empty queue
		ImplementaionOfQueueByUsingStack queue = new ImplementaionOfQueueByUsingStack();
		
		// enqueue new elements to queue
		queue.enqueue(10);
		queue.enqueue(29);
		queue.enqueue(50);
		queue.enqueue(30);
		
		log.info("Queue elements after inset ::"+queue.toString());
		
	    // dequeue elemets in Queue
		log.info("Dequeue element in Quque is "+queue.dequeue());
		log.info("After Dqueue queue elements are "+queue.toString());
	}
}
