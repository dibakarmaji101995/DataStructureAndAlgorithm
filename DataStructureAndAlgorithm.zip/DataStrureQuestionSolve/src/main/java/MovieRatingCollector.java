import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class MovieRatingCollector {
    
    public static class RatingCollectorImpl implements RatingCollector {
    	Map<String,List<Double>> map = new HashMap<String,List<Double>>();
    	
        public void putNewRating(String movie, double rating) {
            // YOUR CODE HERE
            if(map.containsKey(movie)){
                List<Double> ratingList = map.get(movie);
                ratingList.add(rating);
            }else{
                // create new List object and set rating on it
                List<Double> ratingList = new ArrayList<Double>();
                // store rating
                ratingList.add(rating);
                map.put(movie, ratingList);
            }
        }

        public double getAverageRating(String movie) {
			// YOUR CODE HERE
			if (movie != null) {
				// get movie key rating list
				List<Double> ratingList = map.get(movie);
				// get size of list
				Integer size = ratingList.size();
				// get sum of all ratings
				double sum = 0;
				for (double rating : ratingList) {
					sum += rating;
				}
				// get average
				double averageRating = sum / size;
				// return averageRating
				return averageRating;
			}
			return 0.0D;
        }

        public int getRatingCount(String movie) {
            // YOUR CODE HERE
            return map.get(movie).size();
        }
    }

    ////////////////// DO NOT MODIFY BELOW THIS LINE ///////////////////

    public interface RatingCollector {
        // This is an input. Make note of this rating.  Rating can be a double number between 0 and 100.
        void putNewRating(String movie, double rating);

        // Get the average rating
        double getAverageRating(String movie);

        // Get the total number of ratings received for the movie
        int getRatingCount(String movie);
    }

    public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);
        int numLines = Integer.parseInt(scanner.nextLine());
        int currentLine = 0;
        while (currentLine++ < numLines) {
            final RatingCollector stats = new RatingCollectorImpl();
            final Set<String> movies = new TreeSet();

            String line = scanner.nextLine();
            String[] inputs = line.split(",");
            for (int i = 0; i < inputs.length; ++i) {
                String[] tokens = inputs[i].split(" ");
                final String symbol = tokens[0];
                movies.add(symbol);
                final double price = Double.parseDouble(tokens[1]);

                stats.putNewRating(symbol, price);

            }

            for (String movie : movies) {
                System.out.println(
                        String.format("%s %.4f %d", movie, stats.getAverageRating(movie), stats.getRatingCount(movie)));
            }

        }
        scanner.close();

    }
}